import { useState } from 'react';

export function MusicGenerator() {
  const [style, setStyle] = useState('synthwave');
  const [mood, setMood] = useState('energetic');
  const [tempo, setTempo] = useState(110);
  const [isPlaying, setIsPlaying] = useState(false);

  const handleGenerate = () => {
    // In a real implementation, this would trigger the ToneSynth component
    setIsPlaying(true);
    console.log(`Generating ${style} music with ${mood} mood at ${tempo} BPM`);
  };

  const handleStop = () => {
    setIsPlaying(false);
    console.log('Stopping music generation');
  };

  return (
    <div className="bg-gray-800 rounded-xl p-6">
      <h2 className="text-2xl font-bold text-white mb-6">AI Music Generator</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div>
          <label className="block text-gray-300 mb-2">Style</label>
          <select
            value={style}
            onChange={(e) => setStyle(e.target.value)}
            className="w-full bg-gray-700 text-white p-3 rounded-lg border border-gray-600 focus:border-cyan-500 focus:outline-none"
          >
            <option value="synthwave">Synthwave</option>
            <option value="lofi">Lo-Fi</option>
            <option value="electronic">Electronic</option>
            <option value="pop">Pop</option>
            <option value="jazz">Jazz</option>
            <option value="rock">Rock</option>
          </select>
        </div>
        
        <div>
          <label className="block text-gray-300 mb-2">Mood</label>
          <select
            value={mood}
            onChange={(e) => setMood(e.target.value)}
            className="w-full bg-gray-700 text-white p-3 rounded-lg border border-gray-600 focus:border-cyan-500 focus:outline-none"
          >
            <option value="energetic">Energetic</option>
            <option value="chill">Chill</option>
            <option value="dramatic">Dramatic</option>
            <option value="happy">Happy</option>
            <option value="melancholic">Melancholic</option>
            <option value="mysterious">Mysterious</option>
          </select>
        </div>
        
        <div>
          <label className="block text-gray-300 mb-2">Tempo (BPM)</label>
          <div className="flex items-center space-x-4">
            <input
              type="range"
              min="60"
              max="180"
              value={tempo}
              onChange={(e) => setTempo(Number(e.target.value))}
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
            />
            <span className="text-white w-12 text-center bg-gray-700 p-2 rounded">{tempo}</span>
          </div>
        </div>
      </div>
      
      <div className="mb-6">
        <label className="block text-gray-300 mb-2">Prompt</label>
        <textarea
          className="w-full bg-gray-700 text-white p-3 rounded-lg border border-gray-600 focus:border-cyan-500 focus:outline-none"
          rows={3}
          placeholder="Describe the music you want to create..."
        />
      </div>
      
      <div className="flex space-x-4">
        <button
          onClick={handleGenerate}
          disabled={isPlaying}
          className="bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-3 px-8 rounded-lg transition-colors flex items-center"
        >
          <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
            <path d="M6.3 2.841A1.5 1.5 0 004 4.11V15.89a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" />
          </svg>
          Generate
        </button>
        
        <button
          onClick={handleStop}
          disabled={!isPlaying}
          className="bg-pink-600 hover:bg-pink-700 text-white font-bold py-3 px-8 rounded-lg transition-colors flex items-center"
        >
          <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
            <path d="M5.75 3a.75.75 0 00-.75.75v12.5c0 .414.336.75.75.75h1.5a.75.75 0 00.75-.75V3.75A.75.75 0 007.25 3h-1.5zM12.75 3a.75.75 0 00-.75.75v12.5c0 .414.336.75.75.75h1.5a.75.75 0 00.75-.75V3.75a.75.75 0 00-.75-.75h-1.5z" />
          </svg>
          Stop
        </button>
      </div>
    </div>
  );
}