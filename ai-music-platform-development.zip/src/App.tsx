import React, { useState, useEffect } from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  Music,
  Mic,
  Guitar,
  Piano,
  Drum,
  Waves,
  Download,
  Upload,
  Plus,
  Trash2,
  Settings,
  Home,
  BarChart3,
  Layers,
  Sparkles,
  Brain,
  Split,
  Share2,
  Save,
  Zap,
  Users,
  DollarSign,
  ChevronRight,
  Sliders,
  RotateCcw,
  Menu,
  Grid,
  List,
  Search,
  Heart,
  Star
} from 'lucide-react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Utility function
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Types
interface Track {
  id: string;
  name: string;
  artist: string;
  duration: number;
  genre: string;
  bpm: number;
  key: string;
  plays: number;
  likes: number;
  downloads: number;
  createdAt: string;
  cover: string;
  isPlaying: boolean;
  stems: Stem[];
}

interface Stem {
  id: string;
  name: string;
  type: 'vocals' | 'drums' | 'bass' | 'melody' | 'other';
  volume: number;
  pan: number;
  muted: boolean;
  solo: boolean;
  color: string;
}

// Sample Data
const sampleAnalyticsData = [
  { name: 'Mon', streams: 4000, revenue: 2400, listeners: 2400 },
  { name: 'Tue', streams: 3000, revenue: 1398, listeners: 2210 },
  { name: 'Wed', streams: 2000, revenue: 9800, listeners: 2290 },
  { name: 'Thu', streams: 2780, revenue: 3908, listeners: 2000 },
  { name: 'Fri', streams: 1890, revenue: 4800, listeners: 2181 },
  { name: 'Sat', streams: 2390, revenue: 3800, listeners: 2500 },
  { name: 'Sun', streams: 3490, revenue: 4300, listeners: 2800 },
];

const genreData = [
  { name: 'Synthwave', value: 35, color: '#8b5cf6' },
  { name: 'Electronic', value: 25, color: '#06b6d4' },
  { name: 'Hip Hop', value: 20, color: '#f59e0b' },
  { name: 'Pop', value: 12, color: '#ec4899' },
  { name: 'Other', value: 8, color: '#6b7280' },
];

const geographicData = [
  { region: 'North America', listeners: 45000 },
  { region: 'Europe', listeners: 38000 },
  { region: 'Asia', listeners: 25000 },
  { region: 'South America', listeners: 18000 },
  { region: 'Africa', listeners: 12000 },
  { region: 'Oceania', listeners: 8000 },
];

const generateSampleTracks = (): Track[] => [
  {
    id: '1',
    name: 'Neon Dreams',
    artist: 'Synthwave AI',
    duration: 234,
    genre: 'Synthwave',
    bpm: 120,
    key: 'A min',
    plays: 12500,
    likes: 890,
    downloads: 234,
    createdAt: '2024-01-15',
    cover: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?auto=format&fit=crop&q=80&w=200&h=200',
    isPlaying: false,
    stems: [
      { id: 's1', name: 'Vocals', type: 'vocals', volume: 75, pan: 0, muted: false, solo: false, color: '#ec4899' },
      { id: 's2', name: 'Drums', type: 'drums', volume: 85, pan: 0, muted: false, solo: false, color: '#f59e0b' },
      { id: 's3', name: 'Synth Bass', type: 'bass', volume: 70, pan: -10, muted: false, solo: false, color: '#8b5cf6' },
      { id: 's4', name: 'Lead Synth', type: 'melody', volume: 80, pan: 10, muted: false, solo: false, color: '#06b6d4' },
    ]
  },
  {
    id: '2',
    name: 'Digital Horizon',
    artist: 'Electronic Dreams',
    duration: 198,
    genre: 'Electronic',
    bpm: 128,
    key: 'C maj',
    plays: 9800,
    likes: 650,
    downloads: 178,
    createdAt: '2024-01-12',
    cover: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&q=80&w=200&h=200',
    isPlaying: false,
    stems: [
      { id: 's5', name: 'Vocals', type: 'vocals', volume: 80, pan: 0, muted: false, solo: false, color: '#ec4899' },
      { id: 's6', name: 'Drums', type: 'drums', volume: 90, pan: 0, muted: false, solo: false, color: '#f59e0b' },
      { id: 's7', name: 'Bass', type: 'bass', volume: 75, pan: 0, muted: false, solo: false, color: '#8b5cf6' },
    ]
  },
  {
    id: '3',
    name: 'City Lights',
    artist: 'Urban Beats',
    duration: 267,
    genre: 'Hip Hop',
    bpm: 95,
    key: 'E min',
    plays: 15200,
    likes: 1200,
    downloads: 456,
    createdAt: '2024-01-10',
    cover: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&q=80&w=200&h=200',
    isPlaying: false,
    stems: [
      { id: 's8', name: 'Vocals', type: 'vocals', volume: 85, pan: 0, muted: false, solo: false, color: '#ec4899' },
      { id: 's9', name: 'Drums', type: 'drums', volume: 88, pan: 0, muted: false, solo: false, color: '#f59e0b' },
      { id: 's10', name: 'Sample', type: 'other', volume: 65, pan: -5, muted: false, solo: false, color: '#10b981' },
    ]
  },
  {
    id: '4',
    name: 'Midnight Drive',
    artist: 'Synthwave AI',
    duration: 312,
    genre: 'Synthwave',
    bpm: 115,
    key: 'D min',
    plays: 18700,
    likes: 1450,
    downloads: 567,
    createdAt: '2024-01-08',
    cover: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&q=80&w=200&h=200',
    isPlaying: false,
    stems: [
      { id: 's11', name: 'Vocals', type: 'vocals', volume: 78, pan: 0, muted: false, solo: false, color: '#ec4899' },
      { id: 's12', name: 'Drums', type: 'drums', volume: 82, pan: 0, muted: false, solo: false, color: '#f59e0b' },
      { id: 's13', name: 'Bass', type: 'bass', volume: 72, pan: -8, muted: false, solo: false, color: '#8b5cf6' },
      { id: 's14', name: 'Arpeggio', type: 'melody', volume: 70, pan: 8, muted: false, solo: false, color: '#06b6d4' },
      { id: 's15', name: 'Pads', type: 'other', volume: 55, pan: 0, muted: false, solo: false, color: '#10b981' },
    ]
  },
];

// Components
const NeonButton: React.FC<{
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  disabled?: boolean;
}> = ({ children, onClick, variant = 'primary', size = 'md', className, disabled }) => {
  const baseStyles = 'font-semibold rounded-lg transition-all duration-300 flex items-center justify-center gap-2 active:scale-95';
  
  const variants = {
    primary: 'bg-gradient-to-r from-violet-600 to-cyan-500 hover:from-violet-500 hover:to-cyan-400 text-white shadow-lg shadow-violet-500/30 hover:shadow-violet-500/50',
    secondary: 'bg-gray-800 hover:bg-gray-700 text-white border border-gray-600 hover:border-violet-500',
    ghost: 'bg-transparent hover:bg-gray-800 text-gray-300 hover:text-white',
    danger: 'bg-red-600 hover:bg-red-500 text-white shadow-lg shadow-red-500/30',
  };

  const sizes = {
    sm: 'px-3 py-1.5 text-sm',
    md: 'px-4 py-2 text-base',
    lg: 'px-6 py-3 text-lg',
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={cn(baseStyles, variants[variant], sizes[size], disabled && 'opacity-50 cursor-not-allowed', className)}
    >
      {children}
    </button>
  );
};

const StatsCard: React.FC<{
  title: string;
  value: string | number;
  icon: React.ReactNode;
  trend?: string;
  trendUp?: boolean;
  color: string;
}> = ({ title, value, icon, trend, trendUp, color }) => (
  <div className="bg-gray-900/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-800 hover:border-violet-500/50 transition-all duration-300 group">
    <div className="flex items-center justify-between">
      <div>
        <p className="text-gray-400 text-sm font-medium">{title}</p>
        <p className="text-3xl font-bold text-white mt-2">{value}</p>
        {trend && (
          <p className={cn('text-sm mt-2 flex items-center gap-1', trendUp ? 'text-emerald-400' : 'text-red-400')}>
            {trendUp ? '↑' : '↓'} {trend}
          </p>
        )}
      </div>
      <div className={cn('p-4 rounded-xl bg-gradient-to-br', color, 'opacity-80 group-hover:opacity-100 transition-opacity')}>
        {icon}
      </div>
    </div>
  </div>
);

// DAW Components
const WaveformVisualizer: React.FC<{
  color?: string;
  animated?: boolean;
}> = ({ color = '#8b5cf6', animated = true }) => {
  const bars = 64;
  
  return (
    <div className="flex items-end justify-center gap-0.5 h-full w-full overflow-hidden rounded-lg bg-gray-900/50">
      {Array.from({ length: bars }).map(() => (
        <div
          className={cn(
            'w-1 rounded-t transition-all duration-150',
            animated ? 'animate-pulse' : ''
          )}
          style={{
            height: `${Math.random() * 70 + 30}%`,
            backgroundColor: color,
          }}
        />
      ))}
    </div>
  );
};

const ChannelStrip: React.FC<{
  stem: Stem;
  onVolumeChange: (id: string, volume: number) => void;
  onPanChange: (id: string, pan: number) => void;
  onToggleMute: (id: string) => void;
  onToggleSolo: (id: string) => void;
  onDelete: (id: string) => void;
}> = ({ stem, onVolumeChange, onPanChange, onToggleMute, onToggleSolo, onDelete }) => {
  const icons = {
    vocals: <Mic className="w-4 h-4" />,
    drums: <Drum className="w-4 h-4" />,
    bass: <Guitar className="w-4 h-4" />,
    melody: <Piano className="w-4 h-4" />,
    other: <Music className="w-4 h-4" />,
  };

  return (
    <div className={cn(
      'flex items-center gap-3 p-3 rounded-xl border transition-all duration-300',
      stem.muted ? 'bg-gray-900/30 border-gray-800 opacity-60' : 'bg-gray-900/50 border-gray-800 hover:border-violet-500/50'
    )}>
      <div className="flex items-center gap-2 min-w-[140px]">
        <div
          className="w-8 h-8 rounded-lg flex items-center justify-center"
          style={{ backgroundColor: stem.color + '30', color: stem.color }}
        >
          {icons[stem.type]}
        </div>
        <span className="text-sm font-medium text-white truncate">{stem.name}</span>
      </div>

      <div className="flex items-center gap-2 flex-1 max-w-[300px]">
        <div className="flex-1 relative">
          <input
            type="range"
            min="0"
            max="100"
            value={stem.volume}
            onChange={(e) => onVolumeChange(stem.id, parseInt(e.target.value))}
            className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
            style={{
              background: `linear-gradient(to right, ${stem.color} 0%, ${stem.color} ${stem.volume}%, #374151 ${stem.volume}%, #374151 100%)`,
            }}
          />
        </div>
        <span className="text-xs text-gray-400 w-8 text-right">{stem.volume}%</span>
      </div>

      <div className="flex items-center gap-2 min-w-[120px]">
        <span className="text-xs text-gray-400">L</span>
        <input
          type="range"
          min="-100"
          max="100"
          value={stem.pan}
          onChange={(e) => onPanChange(stem.id, parseInt(e.target.value))}
          className="flex-1 h-1.5 bg-gray-700 rounded-lg appearance-none cursor-pointer"
        />
        <span className="text-xs text-gray-400">R</span>
      </div>

      <div className="flex items-center gap-1">
        <button
          onClick={() => onToggleMute(stem.id)}
          className={cn(
            'w-8 h-8 rounded-lg text-xs font-bold transition-all',
            stem.muted ? 'bg-red-500 text-white' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
          )}
        >
          M
        </button>
        <button
          onClick={() => onToggleSolo(stem.id)}
          className={cn(
            'w-8 h-8 rounded-lg text-xs font-bold transition-all',
            stem.solo ? 'bg-amber-500 text-white' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
          )}
        >
          S
        </button>
        <button
          onClick={() => onDelete(stem.id)}
          className="w-8 h-8 rounded-lg bg-gray-800 text-gray-400 hover:bg-red-500 hover:text-white transition-all"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

const DAW: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [totalDuration] = useState(234);
  const [masterVolume, setMasterVolume] = useState(80);
  const [bpm, setBpm] = useState(120);
  const [stems, setStems] = useState<Stem[]>([
    { id: 's1', name: 'Lead Vocals', type: 'vocals', volume: 78, pan: 0, muted: false, solo: false, color: '#ec4899' },
    { id: 's2', name: 'Drums', type: 'drums', volume: 85, pan: 0, muted: false, solo: false, color: '#f59e0b' },
    { id: 's3', name: 'Synth Bass', type: 'bass', volume: 72, pan: -5, muted: false, solo: false, color: '#8b5cf6' },
    { id: 's4', name: 'Lead Synth', type: 'melody', volume: 70, pan: 10, muted: false, solo: false, color: '#06b6d4' },
    { id: 's5', name: 'Pads', type: 'other', volume: 55, pan: 0, muted: false, solo: false, color: '#10b981' },
    { id: 's6', name: 'Arpeggio', type: 'melody', volume: 45, pan: -10, muted: false, solo: false, color: '#eab308' },
  ]);

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTime((prev) => (prev >= totalDuration ? 0 : prev + 0.1));
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isPlaying, totalDuration]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 100);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}:${ms.toString().padStart(2, '0')}`;
  };

  const handleVolumeChange = (id: string, volume: number) => {
    setStems(stems.map(s => s.id === id ? { ...s, volume } : s));
  };

  const handlePanChange = (id: string, pan: number) => {
    setStems(stems.map(s => s.id === id ? { ...s, pan } : s));
  };

  const handleToggleMute = (id: string) => {
    setStems(stems.map(s => s.id === id ? { ...s, muted: !s.muted } : s));
  };

  const handleToggleSolo = (id: string) => {
    setStems(stems.map(s => s.id === id ? { ...s, solo: !s.solo } : s));
  };

  const handleDeleteStem = (id: string) => {
    setStems(stems.filter(s => s.id !== id));
  };

  const addStem = () => {
    const types: Array<'vocals' | 'drums' | 'bass' | 'melody' | 'other'> = ['vocals', 'drums', 'bass', 'melody', 'other'];
    const colors = ['#ec4899', '#f59e0b', '#8b5cf6', '#06b6d4', '#10b981', '#eab308', '#f97316'];
    const newStem: Stem = {
      id: `s${Date.now()}`,
      name: `New Track ${stems.length + 1}`,
      type: types[Math.floor(Math.random() * types.length)],
      volume: 75,
      pan: 0,
      muted: false,
      solo: false,
      color: colors[Math.floor(Math.random() * colors.length)],
    };
    setStems([...stems, newStem]);
  };

  return (
    <div className="flex flex-col h-full bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 rounded-2xl border border-gray-800 overflow-hidden">
      {/* DAW Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-800 bg-gray-900/80 backdrop-blur-xl">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Waves className="w-6 h-6 text-violet-500" />
            <span className="text-xl font-bold bg-gradient-to-r from-violet-400 to-cyan-400 bg-clip-text text-transparent">
              Mureka DAW
            </span>
          </div>
          <div className="h-6 w-px bg-gray-700" />
          <span className="text-sm text-gray-400">Project: Neon Dreams v2</span>
        </div>

        <div className="flex items-center gap-6">
          {/* BPM Control */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-400 uppercase tracking-wider">BPM</span>
            <input
              type="number"
              value={bpm}
              onChange={(e) => setBpm(parseInt(e.target.value) || 120)}
              className="w-16 bg-gray-800 border border-gray-700 rounded-lg px-2 py-1 text-center text-white font-mono focus:outline-none focus:border-violet-500"
            />
          </div>

          {/* Time Display */}
          <div className="bg-gray-800 rounded-lg px-4 py-2 font-mono text-xl text-violet-400 border border-gray-700">
            {formatTime(currentTime)}
          </div>

          {/* Master Volume */}
          <div className="flex items-center gap-2">
            <Volume2 className="w-5 h-5 text-gray-400" />
            <input
              type="range"
              min="0"
              max="100"
              value={masterVolume}
              onChange={(e) => setMasterVolume(parseInt(e.target.value))}
              className="w-32 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
              style={{
                background: `linear-gradient(to right, #8b5cf6 0%, #8b5cf6 ${masterVolume}%, #374151 ${masterVolume}%, #374151 100%)`,
              }}
            />
            <span className="text-sm text-gray-400 w-8">{masterVolume}%</span>
          </div>

          <div className="flex items-center gap-2">
            <NeonButton variant="ghost" size="sm" onClick={() => setCurrentTime(0)}>
              <RotateCcw className="w-4 h-4" />
            </NeonButton>
            <NeonButton variant="secondary" size="sm" onClick={() => setCurrentTime(Math.max(0, currentTime - 5))}>
              <SkipBack className="w-4 h-4" />
            </NeonButton>
            <NeonButton size="lg" onClick={() => setIsPlaying(!isPlaying)} className="w-14 h-14 rounded-full p-0">
              {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-1" />}
            </NeonButton>
            <NeonButton variant="secondary" size="sm" onClick={() => setCurrentTime(Math.min(totalDuration, currentTime + 5))}>
              <SkipForward className="w-4 h-4" />
            </NeonButton>
          </div>

          <div className="flex items-center gap-2">
            <NeonButton variant="secondary" size="sm">
              <Save className="w-4 h-4" />
              Save
            </NeonButton>
            <NeonButton size="sm">
              <Download className="w-4 h-4" />
              Export
            </NeonButton>
          </div>
        </div>
      </div>

      {/* Main Waveform Display */}
      <div className="flex-1 p-4 overflow-auto">
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-400">Master Waveform</h3>
            <div className="flex items-center gap-2">
              {[...Array(8)].map((_, index) => (
                <div
                  key={index}
                  className={cn(
                    'w-2 h-8 rounded-full transition-all duration-150',
                    isPlaying ? 'animate-pulse' : ''
                  )}
                  style={{
                    height: isPlaying ? `${Math.random() * 80 + 20}%` : '20%',
                    backgroundColor: isPlaying ? (index % 2 === 0 ? '#8b5cf6' : '#06b6d4') : '#4b5563',
                    animationDelay: `${index * 50}ms`,
                  }}
                />
              ))}
            </div>
          </div>
          <div className="relative h-32 bg-gray-900/50 rounded-xl border border-gray-800 overflow-hidden">
            <WaveformVisualizer animated={isPlaying} />
            {/* Timeline */}
            <div className="absolute bottom-0 left-0 right-0 h-6 bg-gray-900/80 flex items-center px-2 border-t border-gray-800">
              {Array.from({ length: 10 }).map((_, index) => (
                <div key={index} className="flex-1 flex flex-col items-center">
                  <div className="w-px h-2 bg-gray-600" />
                  <span className="text-xs text-gray-500 mt-0.5">{index * 24}s</span>
                </div>
              ))}
            </div>
            {/* Playhead */}
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-10"
              style={{ left: `${(currentTime / totalDuration) * 100}%` }}
            >
              <div className="absolute -top-1 -left-1.5 w-3 h-3 bg-red-500 rotate-45" />
            </div>
          </div>
        </div>

        {/* Channel Strips */}
        <div className="space-y-2">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-gray-400">Mixer Channels</h3>
            <NeonButton variant="ghost" size="sm" onClick={addStem}>
              <Plus className="w-4 h-4" />
              Add Track
            </NeonButton>
          </div>
          {stems.map((stem) => (
            <ChannelStrip
              key={stem.id}
              stem={stem}
              onVolumeChange={handleVolumeChange}
              onPanChange={handlePanChange}
              onToggleMute={handleToggleMute}
              onToggleSolo={handleToggleSolo}
              onDelete={handleDeleteStem}
            />
          ))}
        </div>

        {/* Timeline Tracks */}
        <div className="mt-6">
          <h3 className="text-sm font-medium text-gray-400 mb-2">Timeline</h3>
          <div className="bg-gray-900/50 rounded-xl border border-gray-800 overflow-hidden">
            {stems.map((stem, index) => (
              <div key={stem.id} className="flex items-center border-b border-gray-800 last:border-b-0">
                <div className="w-32 p-2 flex items-center gap-2 bg-gray-900/80 border-r border-gray-800">
                  <div className="w-3 h-3 rounded" style={{ backgroundColor: stem.color }} />
                  <span className="text-xs text-gray-300 truncate">{stem.name}</span>
                </div>
                <div className="flex-1 h-12 relative">
                  {/* Clip visualization */}
                  <div
                    className="absolute top-1 bottom-1 left-[5%] right-[20%] rounded opacity-80 hover:opacity-100 cursor-pointer transition-opacity"
                    style={{ backgroundColor: stem.color + '40', borderLeft: `3px solid ${stem.color}` }}
                  >
                    <div className="absolute inset-0 flex items-center gap-0.5 px-2 overflow-hidden">
                      {Array.from({ length: 40 }).map(() => (
                        <div
                          key={index}
                          className="w-0.5 rounded-full"
                          style={{
                            height: `${Math.random() * 60 + 20}%`,
                            backgroundColor: stem.color,
                          }}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// AI Generator Component
const AIGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [genre, setGenre] = useState('synthwave');
  const [mood, setMood] = useState('energetic');
  const [duration, setDuration] = useState(180);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [generatedTracks, setGeneratedTracks] = useState<{id: string, name: string, preview: string}[]>([]);

  const genres = [
    { id: 'synthwave', name: 'Synthwave', icon: <Waves className="w-5 h-5" /> },
    { id: 'electronic', name: 'Electronic', icon: <Zap className="w-5 h-5" /> },
    { id: 'hiphop', name: 'Hip Hop', icon: <Mic className="w-5 h-5" /> },
    { id: 'pop', name: 'Pop', icon: <Star className="w-5 h-5" /> },
    { id: 'jazz', name: 'Jazz', icon: <Piano className="w-5 h-5" /> },
    { id: 'rock', name: 'Rock', icon: <Guitar className="w-5 h-5" /> },
  ];

  const moods = [
    { id: 'energetic', name: 'Energetic' },
    { id: 'relaxed', name: 'Relaxed' },
    { id: 'dramatic', name: 'Dramatic' },
    { id: 'mysterious', name: 'Mysterious' },
    { id: 'happy', name: 'Happy' },
    { id: 'sad', name: 'Sad' },
  ];

  const handleGenerate = () => {
    if (!prompt.trim()) return;
    setIsGenerating(true);
    setGenerationProgress(0);

    const interval = setInterval(() => {
      setGenerationProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsGenerating(false);
          setGeneratedTracks(prev => [...prev, {
            id: Date.now().toString(),
            name: `${genre.charAt(0).toUpperCase() + genre.slice(1)} - ${mood.charAt(0).toUpperCase() + mood.slice(1)}`,
            preview: prompt
          }]);
          return 0;
        }
        return prev + 2;
      });
    }, 100);
  };

  return (
    <div className="space-y-6">
      <div className="bg-gray-900/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-800">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-gradient-to-br from-violet-600 to-cyan-500 rounded-xl">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">AI Music Generator</h2>
            <p className="text-gray-400 text-sm">Create unique tracks with AI-powered composition</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Describe your track
              </label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="E.g., A futuristic synthwave track with driving basslines, atmospheric pads, and a catchy melody. Perfect for a retro 80s movie scene with modern production quality..."
                className="w-full h-32 bg-gray-800/50 border border-gray-700 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-violet-500 focus:ring-2 focus:ring-violet-500/20 resize-none transition-all"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Genre</label>
              <div className="grid grid-cols-3 gap-2">
                {genres.map((g) => (
                  <button
                    key={g.id}
                    onClick={() => setGenre(g.id)}
                    className={cn(
                      'flex flex-col items-center gap-2 p-3 rounded-xl border transition-all',
                      genre === g.id
                        ? 'bg-violet-600/20 border-violet-500 text-violet-400'
                        : 'bg-gray-800/50 border-gray-700 text-gray-400 hover:border-gray-600'
                    )}
                  >
                    {g.icon}
                    <span className="text-xs font-medium">{g.name}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Mood</label>
              <div className="flex flex-wrap gap-2">
                {moods.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => setMood(m.id)}
                    className={cn(
                      'px-4 py-2 rounded-lg text-sm font-medium transition-all',
                      mood === m.id
                        ? 'bg-cyan-600/20 border border-cyan-500 text-cyan-400'
                        : 'bg-gray-800/50 border border-gray-700 text-gray-400 hover:border-gray-600'
                    )}
                  >
                    {m.name}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Duration: {duration}s ({Math.floor(duration / 60)}:{(duration % 60).toString().padStart(2, '0')})
              </label>
              <input
                type="range"
                min="30"
                max="300"
                step="15"
                value={duration}
                onChange={(e) => setDuration(parseInt(e.target.value))}
                className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to right, #8b5cf6 0%, #8b5cf6 ${((duration - 30) / 270) * 100}%, #374151 ${((duration - 30) / 270) * 100}%, #374151 100%)`,
                }}
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>30s</span>
                <span>5min</span>
              </div>
            </div>

            <NeonButton
              onClick={handleGenerate}
              disabled={isGenerating || !prompt.trim()}
              className="w-full py-4 text-lg"
            >
              {isGenerating ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Generating... {generationProgress}%
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  Generate Track
                </>
              )}
            </NeonButton>

            {isGenerating && (
              <div className="bg-gray-800/50 rounded-xl p-4">
                <div className="flex justify-between text-sm text-gray-400 mb-2">
                  <span>AI is composing your track...</span>
                  <span>{generationProgress}%</span>
                </div>
                <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-violet-600 to-cyan-500 transition-all duration-300"
                    style={{ width: `${generationProgress}%` }}
                  />
                </div>
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-white">Generated Tracks</h3>
              <span className="text-sm text-gray-400">{generatedTracks.length} tracks</span>
            </div>

            {generatedTracks.length === 0 ? (
              <div className="h-64 flex flex-col items-center justify-center text-gray-500 border-2 border-dashed border-gray-800 rounded-xl">
                <Music className="w-12 h-12 mb-4 opacity-50" />
                <p>No tracks generated yet</p>
                <p className="text-sm">Describe your vision and click Generate</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-96 overflow-auto">
                {generatedTracks.map((track) => (
                  <div key={track.id} className="bg-gray-800/50 rounded-xl p-4 border border-gray-700 hover:border-violet-500/50 transition-all">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="font-semibold text-white">{track.name}</h4>
                        <p className="text-sm text-gray-400 truncate max-w-xs">{track.preview}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button className="w-10 h-10 rounded-full bg-gradient-to-r from-violet-600 to-cyan-500 flex items-center justify-center text-white hover:scale-105 transition-transform">
                          <Play className="w-5 h-5 ml-0.5" />
                        </button>
                      </div>
                    </div>
                    <div className="h-12 bg-gray-900/50 rounded-lg overflow-hidden">
                      <WaveformVisualizer animated={false} />
                    </div>
                    <div className="flex items-center justify-between mt-3">
                      <span className="text-xs text-gray-500">{duration}s • {genre} • {mood}</span>
                      <div className="flex items-center gap-2">
                        <button className="px-3 py-1 text-xs bg-gray-700 text-gray-300 rounded-lg hover:bg-gray-600 transition-colors">
                          <Layers className="w-3 h-3 inline mr-1" />
                          Stems
                        </button>
                        <button className="px-3 py-1 text-xs bg-violet-600/20 text-violet-400 rounded-lg hover:bg-violet-600/30 transition-colors">
                          <Download className="w-3 h-3 inline mr-1" />
                          Export
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Quick Prompts */}
      <div className="bg-gray-900/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-800">
        <h3 className="text-lg font-semibold text-white mb-4">Quick Start Templates</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { title: 'Epic Film Score', desc: 'Dramatic orchestral with electronic elements', icon: <Sparkles className="w-5 h-5" /> },
            { title: 'Lo-Fi Hip Hop', desc: 'Chill beats with jazzy samples', icon: <Music className="w-5 h-5" /> },
            { title: 'EDM Anthem', desc: 'High-energy drop with powerful synths', icon: <Zap className="w-5 h-5" /> },
          ].map((template, i) => (
            <button
              key={i}
              onClick={() => setPrompt(template.desc)}
              className="flex items-start gap-4 p-4 bg-gray-800/50 rounded-xl border border-gray-700 hover:border-violet-500/50 transition-all text-left group"
            >
              <div className="p-2 bg-violet-600/20 rounded-lg text-violet-400 group-hover:bg-violet-600/30 transition-colors">
                {template.icon}
              </div>
              <div>
                <h4 className="font-semibold text-white">{template.title}</h4>
                <p className="text-sm text-gray-400">{template.desc}</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

// Stem Separator Component
const StemSeparator: React.FC = () => {
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [separatedStems, setSeparatedStems] = useState<{name: string, type: string, color: string, size: string}[]>([]);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    startProcessing();
  };

  const startProcessing = () => {
    setIsProcessing(true);
    setProgress(0);
    setSeparatedStems([]);

    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsProcessing(false);
          setSeparatedStems([
            { name: 'Vocals', type: 'Lead & Background', color: '#ec4899', size: '2.4 MB' },
            { name: 'Drums', type: 'Full Kit', color: '#f59e0b', size: '3.1 MB' },
            { name: 'Bass', type: 'Bass Guitar', color: '#8b5cf6', size: '1.8 MB' },
            { name: 'Instruments', type: 'Guitars & Keys', color: '#06b6d4', size: '4.2 MB' },
          ]);
          return 100;
        }
        return prev + 1;
      });
    }, 50);
  };

  return (
    <div className="space-y-6">
      <div className="bg-gray-900/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-800">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-gradient-to-br from-pink-600 to-orange-500 rounded-xl">
            <Split className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">Stem Separation</h2>
            <p className="text-gray-400 text-sm">Isolate vocals, drums, bass, and instruments from any track</p>
          </div>
        </div>

        <div
          onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          onClick={() => !isProcessing && startProcessing()}
          className={cn(
            'relative border-2 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-all duration-300',
            isDragging ? 'border-violet-500 bg-violet-500/10' : 'border-gray-700 hover:border-gray-600 bg-gray-900/30',
            isProcessing && 'cursor-not-allowed'
          )}
        >
          {isProcessing ? (
            <div className="space-y-4">
              <div className="w-16 h-16 mx-auto rounded-full border-4 border-violet-500/30 border-t-violet-500 animate-spin" />
              <div>
                <h3 className="text-lg font-semibold text-white">Separating Stems...</h3>
                <p className="text-gray-400">AI is analyzing your audio</p>
              </div>
              <div className="max-w-md mx-auto">
                <div className="flex justify-between text-sm text-gray-400 mb-2">
                  <span>Processing</span>
                  <span>{progress}%</span>
                </div>
                <div className="h-2 bg-gray-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-violet-600 to-cyan-500 transition-all duration-100"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="w-20 h-20 mx-auto rounded-2xl bg-gradient-to-br from-violet-600/20 to-cyan-500/20 flex items-center justify-center">
                <Upload className="w-10 h-10 text-violet-400" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-white mb-2">Drag & drop your audio file</h3>
                <p className="text-gray-400 mb-4">or click to browse • Supports MP3, WAV, FLAC • Max 100MB</p>
                <NeonButton>
                  <Plus className="w-5 h-5" />
                  Select File
                </NeonButton>
              </div>
            </div>
          )}
        </div>
      </div>

      {separatedStems.length > 0 && (
        <div className="bg-gray-900/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-800">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-white">Separated Stems</h3>
            <div className="flex items-center gap-2">
              <NeonButton variant="secondary" size="sm">
                <Download className="w-4 h-4" />
                Download All
              </NeonButton>
              <NeonButton size="sm">
                <Layers className="w-4 h-4" />
                Send to DAW
              </NeonButton>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {separatedStems.map((stem, i) => (
              <div key={i} className="bg-gray-800/50 rounded-xl p-4 border border-gray-700 hover:border-violet-500/50 transition-all">
                <div className="flex items-center gap-4">
                  <div
                    className="w-14 h-14 rounded-xl flex items-center justify-center"
                    style={{ backgroundColor: stem.color + '20' }}
                  >
                    {i === 0 && <Mic className="w-7 h-7" style={{ color: stem.color }} />}
                    {i === 1 && <Drum className="w-7 h-7" style={{ color: stem.color }} />}
                    {i === 2 && <Guitar className="w-7 h-7" style={{ color: stem.color }} />}
                    {i === 3 && <Piano className="w-7 h-7" style={{ color: stem.color }} />}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-white">{stem.name}</h4>
                    <p className="text-sm text-gray-400">{stem.type} • {stem.size}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="w-10 h-10 rounded-full bg-gradient-to-r from-violet-600 to-cyan-500 flex items-center justify-center text-white hover:scale-105 transition-transform">
                      <Play className="w-5 h-5 ml-0.5" />
                    </button>
                    <button className="w-10 h-10 rounded-lg bg-gray-700 text-gray-300 hover:bg-gray-600 flex items-center justify-center transition-colors">
                      <Download className="w-5 h-5" />
                    </button>
                  </div>
                </div>
                <div className="mt-4 h-12 bg-gray-900/50 rounded-lg overflow-hidden">
                  <WaveformVisualizer color={stem.color} animated={false} />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// Analytics Component
const Analytics: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Total Streams"
          value="1.2M"
          icon={<Play className="w-6 h-6 text-white" />}
          trend="+12.5%"
          trendUp={true}
          color="from-violet-600 to-violet-400"
        />
        <StatsCard
          title="Revenue"
          value="$24,580"
          icon={<DollarSign className="w-6 h-6 text-white" />}
          trend="+8.2%"
          trendUp={true}
          color="from-emerald-600 to-emerald-400"
        />
        <StatsCard
          title="Active Listeners"
          value="45.2K"
          icon={<Users className="w-6 h-6 text-white" />}
          trend="+15.3%"
          trendUp={true}
          color="from-cyan-600 to-cyan-400"
        />
        <StatsCard
          title="Total Tracks"
          value="156"
          icon={<Music className="w-6 h-6 text-white" />}
          trend="+12"
          trendUp={true}
          color="from-orange-600 to-orange-400"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Streams Chart */}
        <div className="bg-gray-900/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-800">
          <h3 className="text-lg font-semibold text-white mb-6">Weekly Performance</h3>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={sampleAnalyticsData}>
              <defs>
                <linearGradient id="colorStreams" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="name" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <Tooltip
                contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '12px' }}
                labelStyle={{ color: '#fff' }}
              />
              <Area type="monotone" dataKey="streams" stroke="#8b5cf6" fillOpacity={1} fill="url(#colorStreams)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Revenue Chart */}
        <div className="bg-gray-900/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-800">
          <h3 className="text-lg font-semibold text-white mb-6">Revenue Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={sampleAnalyticsData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="name" stroke="#9ca3af" />
              <YAxis stroke="#9ca3af" />
              <Tooltip
                contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '12px' }}
                labelStyle={{ color: '#fff' }}
              />
              <Line type="monotone" dataKey="revenue" stroke="#06b6d4" strokeWidth={3} dot={{ fill: '#06b6d4', strokeWidth: 2 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Genre Distribution */}
        <div className="bg-gray-900/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-800">
          <h3 className="text-lg font-semibold text-white mb-6">Genre Distribution</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={genreData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={5}
                dataKey="value"
              >
                {genreData.map((entry) => (
                  <Cell key={`cell-${entry.name}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '12px' }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-4">
            {genreData.map((genre) => (
              <div key={genre.name} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: genre.color }} />
                  <span className="text-gray-400">{genre.name}</span>
                </div>
                <span className="text-white font-medium">{genre.value}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* Geographic Data */}
        <div className="bg-gray-900/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-800 lg:col-span-2">
          <h3 className="text-lg font-semibold text-white mb-6">Listener Distribution</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={geographicData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis type="number" stroke="#9ca3af" />
              <YAxis dataKey="region" type="category" stroke="#9ca3af" width={120} />
              <Tooltip
                contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '12px' }}
                labelStyle={{ color: '#fff' }}
              />
              <Bar dataKey="listeners" fill="url(#barGradient)" radius={[0, 8, 8, 0]}>
                <defs>
                  <linearGradient id="barGradient" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="#8b5cf6" />
                    <stop offset="100%" stopColor="#06b6d4" />
                  </linearGradient>
                </defs>
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

// Track Library Component
const TrackLibrary: React.FC = () => {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [tracks] = useState<Track[]>(generateSampleTracks());
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('all');

  const filteredTracks = tracks.filter(track => {
    const matchesSearch = track.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      track.artist.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGenre = selectedGenre === 'all' || track.genre === selectedGenre;
    return matchesSearch && matchesGenre;
  });

  const genres = ['all', 'Synthwave', 'Electronic', 'Hip Hop', 'Pop'];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white">Track Library</h2>
          <p className="text-gray-400">{tracks.length} tracks in your library</p>
        </div>
        <div className="flex items-center gap-3">
          <NeonButton>
            <Plus className="w-5 h-5" />
            Upload Track
          </NeonButton>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-gray-900/50 backdrop-blur-xl rounded-2xl p-4 border border-gray-800">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="text"
              placeholder="Search tracks..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-gray-800 border border-gray-700 rounded-xl pl-10 pr-4 py-2.5 text-white placeholder-gray-500 focus:outline-none focus:border-violet-500 transition-colors"
            />
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              {genres.map((genre) => (
                <button
                  key={genre}
                  onClick={() => setSelectedGenre(genre)}
                  className={cn(
                    'px-4 py-2 rounded-lg text-sm font-medium transition-all',
                    selectedGenre === genre
                      ? 'bg-violet-600 text-white'
                      : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                  )}
                >
                  {genre.charAt(0).toUpperCase() + genre.slice(1)}
                </button>
              ))}
            </div>
            <div className="h-8 w-px bg-gray-700" />
            <div className="flex items-center gap-1 bg-gray-800 rounded-lg p-1">
              <button
                onClick={() => setViewMode('grid')}
                className={cn(
                  'p-2 rounded-lg transition-all',
                  viewMode === 'grid' ? 'bg-violet-600 text-white' : 'text-gray-400 hover:text-white'
                )}
              >
                <Grid className="w-5 h-5" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={cn(
                  'p-2 rounded-lg transition-all',
                  viewMode === 'list' ? 'bg-violet-600 text-white' : 'text-gray-400 hover:text-white'
                )}
              >
                <List className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Tracks */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredTracks.map((track) => (
            <div key={track.id} className="bg-gray-900/50 backdrop-blur-xl rounded-2xl overflow-hidden border border-gray-800 hover:border-violet-500/50 transition-all group">
              <div className="relative aspect-square">
                <img src={track.cover} alt={track.name} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <button className="w-14 h-14 rounded-full bg-gradient-to-r from-violet-600 to-cyan-500 flex items-center justify-center text-white hover:scale-110 transition-transform">
                    <Play className="w-7 h-7 ml-1" />
                  </button>
                </div>
              </div>
              <div className="p-4">
                <h3 className="font-semibold text-white truncate">{track.name}</h3>
                <p className="text-sm text-gray-400 truncate">{track.artist}</p>
                <div className="flex items-center justify-between mt-3">
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span className="flex items-center gap-1"><Play className="w-3 h-3" />{track.plays.toLocaleString()}</span>
                    <span className="flex items-center gap-1"><Heart className="w-3 h-3" />{track.likes}</span>
                  </div>
                  <span className="text-xs bg-violet-600/20 text-violet-400 px-2 py-1 rounded-lg">{track.genre}</span>
                </div>
                <div className="flex items-center gap-2 mt-4">
                  <NeonButton variant="secondary" size="sm" className="flex-1">
                    <Layers className="w-4 h-4" />
                    Stems
                  </NeonButton>
                  <NeonButton size="sm" className="flex-1">
                    <Download className="w-4 h-4" />
                    Download
                  </NeonButton>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-gray-900/50 backdrop-blur-xl rounded-2xl border border-gray-800 overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-800/50">
              <tr className="text-left text-gray-400 text-sm">
                <th className="p-4 font-medium">Track</th>
                <th className="p-4 font-medium">Artist</th>
                <th className="p-4 font-medium">Genre</th>
                <th className="p-4 font-medium">BPM</th>
                <th className="p-4 font-medium">Key</th>
                <th className="p-4 font-medium">Plays</th>
                <th className="p-4 font-medium">Duration</th>
                <th className="p-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredTracks.map((track) => (
                <tr key={track.id} className={cn('border-t border-gray-800 hover:bg-gray-800/30 transition-colors')}>
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <img src={track.cover} alt={track.name} className="w-10 h-10 rounded-lg object-cover" />
                      <span className="font-medium text-white">{track.name}</span>
                    </div>
                  </td>
                  <td className="p-4 text-gray-400">{track.artist}</td>
                  <td className="p-4"><span className="text-xs bg-violet-600/20 text-violet-400 px-2 py-1 rounded-lg">{track.genre}</span></td>
                  <td className="p-4 text-gray-400">{track.bpm}</td>
                  <td className="p-4 text-gray-400">{track.key}</td>
                  <td className="p-4 text-gray-400">{track.plays.toLocaleString()}</td>
                  <td className="p-4 text-gray-400">{Math.floor(track.duration / 60)}:{(track.duration % 60).toString().padStart(2, '0')}</td>
                  <td className="p-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button className="w-8 h-8 rounded-lg bg-gray-800 text-gray-400 hover:text-white hover:bg-gray-700 flex items-center justify-center">
                        <Play className="w-4 h-4" />
                      </button>
                      <button className="w-8 h-8 rounded-lg bg-gray-800 text-gray-400 hover:text-white hover:bg-gray-700 flex items-center justify-center">
                        <Layers className="w-4 h-4" />
                      </button>
                      <button className="w-8 h-8 rounded-lg bg-gray-800 text-gray-400 hover:text-white hover:bg-gray-700 flex items-center justify-center">
                        <Download className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

// Main App Component
export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'daw' | 'generator' | 'stems' | 'library' | 'analytics'>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: <Home className="w-5 h-5" /> },
    { id: 'daw', label: 'DAW Studio', icon: <Sliders className="w-5 h-5" /> },
    { id: 'generator', label: 'AI Generator', icon: <Sparkles className="w-5 h-5" /> },
    { id: 'stems', label: 'Stem Separator', icon: <Split className="w-5 h-5" /> },
    { id: 'library', label: 'Track Library', icon: <Music className="w-5 h-5" /> },
    { id: 'analytics', label: 'Analytics', icon: <BarChart3 className="w-5 h-5" /> },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'daw':
        return <DAW />;
      case 'generator':
        return <AIGenerator />;
      case 'stems':
        return <StemSeparator />;
      case 'library':
        return <TrackLibrary />;
      case 'analytics':
        return <Analytics />;
      default:
        return (
          <div className="space-y-6">
            {/* Welcome Section */}
            <div className="bg-gradient-to-r from-violet-600/20 via-cyan-600/20 to-pink-600/20 rounded-2xl p-8 border border-violet-500/30">
              <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">Welcome to Mureka Studio</h1>
                  <p className="text-gray-300 max-w-xl">Your complete AI-powered music production platform. Create, edit, and share professional tracks with cutting-edge AI tools.</p>
                </div>
                <div className="flex items-center gap-3">
                  <NeonButton size="lg" onClick={() => setActiveTab('generator')}>
                    <Sparkles className="w-5 h-5" />
                    Create with AI
                  </NeonButton>
                  <NeonButton variant="secondary" size="lg" onClick={() => setActiveTab('daw')}>
                    <Sliders className="w-5 h-5" />
                    Open DAW
                  </NeonButton>
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <StatsCard
                title="Projects"
                value="24"
                icon={<Layers className="w-6 h-6 text-white" />}
                trend="+3 this week"
                trendUp={true}
                color="from-violet-600 to-violet-400"
              />
              <StatsCard
                title="AI Generations"
                value="156"
                icon={<Brain className="w-6 h-6 text-white" />}
                trend="+28 today"
                trendUp={true}
                color="from-cyan-600 to-cyan-400"
              />
              <StatsCard
                title="Stems Separated"
                value="89"
                icon={<Split className="w-6 h-6 text-white" />}
                trend="+12 this week"
                trendUp={true}
                color="from-pink-600 to-pink-400"
              />
              <StatsCard
                title="Exported Tracks"
                value="47"
                icon={<Download className="w-6 h-6 text-white" />}
                trend="+8 today"
                trendUp={true}
                color="from-orange-600 to-orange-400"
              />
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <button
                onClick={() => setActiveTab('generator')}
                className="bg-gray-900/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-800 hover:border-violet-500/50 transition-all text-left group"
              >
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-violet-600 to-cyan-500 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                  <Sparkles className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">AI Music Generator</h3>
                <p className="text-gray-400">Create unique tracks with AI-powered composition and custom vocal styles</p>
              </button>

              <button
                onClick={() => setActiveTab('stems')}
                className="bg-gray-900/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-800 hover:border-pink-500/50 transition-all text-left group"
              >
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-pink-600 to-orange-500 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                  <Split className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Stem Separation</h3>
                <p className="text-gray-400">Isolate vocals, drums, bass, and instruments from any track in seconds</p>
              </button>

              <button
                onClick={() => setActiveTab('daw')}
                className="bg-gray-900/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-800 hover:border-cyan-500/50 transition-all text-left group"
              >
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-cyan-600 to-emerald-500 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                  <Sliders className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">DAW Studio</h3>
                <p className="text-gray-400">Professional multi-track editing with real-time effects and automation</p>
              </button>
            </div>

            {/* Recent Projects */}
            <div className="bg-gray-900/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-800">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold text-white">Recent Projects</h3>
                <NeonButton variant="ghost" onClick={() => setActiveTab('library')}>
                  View All
                  <ChevronRight className="w-4 h-4" />
                </NeonButton>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {generateSampleTracks().slice(0, 4).map((track) => (
                  <div
                    key={track.id}
                    className="bg-gray-800/50 rounded-xl p-4 border border-gray-700 hover:border-violet-500/50 transition-all cursor-pointer group"
                    onClick={() => setActiveTab('daw')}
                  >
                    <div className="relative mb-4">
                      <img src={track.cover} alt={track.name} className="w-full aspect-square object-cover rounded-lg" />
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-lg">
                        <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center">
                          <Play className="w-5 h-5 text-gray-900 ml-0.5" />
                        </div>
                      </div>
                    </div>
                    <h4 className="font-semibold text-white truncate">{track.name}</h4>
                    <p className="text-sm text-gray-400">{track.genre} • {track.bpm} BPM</p>
                    <p className="text-xs text-gray-500 mt-2">{track.createdAt}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 text-white flex">
      {/* Sidebar */}
      <aside className={cn(
        'fixed lg:relative inset-y-0 left-0 z-50 bg-gray-900/95 backdrop-blur-xl border-r border-gray-800 transition-all duration-300 flex flex-col',
        sidebarOpen ? 'w-64' : 'w-20 lg:w-20'
      )}>
        {/* Logo */}
        <div className="p-6 border-b border-gray-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-600 to-cyan-500 flex items-center justify-center flex-shrink-0">
              <Waves className="w-6 h-6 text-white" />
            </div>
            {sidebarOpen && (
              <span className="text-xl font-bold bg-gradient-to-r from-violet-400 to-cyan-400 bg-clip-text text-transparent">
                Mureka
              </span>
            )}
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2 overflow-auto">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={cn(
                'w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300',
                activeTab === item.id
                  ? 'bg-gradient-to-r from-violet-600/20 to-cyan-600/20 border border-violet-500/50 text-violet-400'
                  : 'text-gray-400 hover:bg-gray-800/50 hover:text-white'
              )}
            >
              {item.icon}
              {sidebarOpen && <span className="font-medium">{item.label}</span>}
            </button>
          ))}
        </nav>

        {/* User Profile */}
        <div className="p-4 border-t border-gray-800">
          <div className={cn('flex items-center gap-3', !sidebarOpen && 'justify-center')}>
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-600 to-cyan-500 flex items-center justify-center flex-shrink-0">
              <span className="font-bold">MU</span>
            </div>
            {sidebarOpen && (
              <div className="flex-1 min-w-0">
                <p className="font-medium text-white truncate">Music User</p>
                <p className="text-xs text-gray-400 truncate">Pro Plan</p>
              </div>
            )}
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-h-screen overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-gray-900/50 backdrop-blur-xl border-b border-gray-800 flex items-center justify-between px-6 flex-shrink-0">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 rounded-lg bg-gray-800 text-gray-400 hover:text-white"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div>
              <h2 className="text-lg font-semibold text-white capitalize">{activeTab}</h2>
              <p className="text-xs text-gray-400">Mureka Studio</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button className="p-2 rounded-lg bg-gray-800 text-gray-400 hover:text-white hover:bg-gray-700 transition-colors relative">
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
              <Zap className="w-5 h-5" />
            </button>
            <button className="p-2 rounded-lg bg-gray-800 text-gray-400 hover:text-white hover:bg-gray-700 transition-colors">
              <Settings className="w-5 h-5" />
            </button>
            <div className="h-8 w-px bg-gray-700" />
            <NeonButton variant="secondary" size="sm">
              <Share2 className="w-4 h-4" />
              Share
            </NeonButton>
            <NeonButton size="sm">
              <Download className="w-4 h-4" />
              Export
            </NeonButton>
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 overflow-auto p-6">
          {renderContent()}
        </div>
      </main>
    </div>
  );
}