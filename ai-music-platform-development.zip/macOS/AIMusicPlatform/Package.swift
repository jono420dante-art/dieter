// swift-tools-version:5.7

import PackageDescription

let package = Package(
    name: "AIMusicPlatform",
    platforms: [
        .macOS(.v12)
    ],
    products: [
        .executable(
            name: "AIMusicPlatform",
            targets: ["AIMusicPlatform"]
        )
    ],
    dependencies: [
        .package(url: "https://github.com/AudioKit/AudioKit.git", from: "5.6.0"),
        .package(url: "https://github.com/AudioKit/AudioKitUI.git", from: "0.4.0")
    ],
    targets: [
        .executableTarget(
            name: "AIMusicPlatform",
            dependencies: ["AudioKit", "AudioKitUI"],
            path: "Sources"
        )
    ]
)