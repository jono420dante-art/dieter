//
//  TrackLibraryView.swift
//  AIMusicPlatform
//
//  Created by AI Assistant on 2024.
//

import SwiftUI
import AVFoundation

struct TrackLibraryView: View {
    @State private var searchText = ""
    @State private var selectedTracks: Set<UUID> = []
    @State private var viewMode: ViewMode = .list
    @State private var sortOrder: SortOrder = .dateAdded
    @State private var isAscending: Bool = false
    @State private var showOnlyFavorites = false
    @State private var selectedGenre: String?
    
    let genres = ["All", "Synthwave", "Lo-fi", "Electronic", "Pop", "Jazz", "Rock", "Hip-Hop"]
    
    @State private var tracks: [LibraryTrack] = [
        LibraryTrack(
            id: UUID(),
            name: "Neon Dreams",
            artist: "Synth Master",
            album: "Retro Future",
            genre: "Synthwave",
            duration: 245,
            createdAt: Date(),
            isFavorite: true,
            playCount: 127,
            filePath: URL(fileURLWithPath: "/path/to/track1.mp3")
        ),
        LibraryTrack(
            id: UUID(),
            name: "Midnight Drive",
            artist: "Neon Rider",
            album: "Night Waves",
            genre: "Synthwave",
            duration: 198,
            createdAt: Date().addingTimeInterval(-86400),
            isFavorite: true,
            playCount: 89,
            filePath: URL(fileURLWithPath: "/path/to/track2.mp3")
        ),
        LibraryTrack(
            id: UUID(),
            name: "Lo-fi Study Session",
            artist: "Chill Beats",
            album: "Study Collection",
            genre: "Lo-fi",
            duration: 180,
            createdAt: Date().addingTimeInterval(-172800),
            isFavorite: false,
            playCount: 45,
            filePath: URL(fileURLWithPath: "/path/to/track3.mp3")
        ),
        LibraryTrack(
            id: UUID(),
            name: "Electric Pulse",
            artist: "Digital Wave",
            album: "Electronic Vibes",
            genre: "Electronic",
            duration: 215,
            createdAt: Date().addingTimeInterval(-259200),
            isFavorite: true,
            playCount: 156,
            filePath: URL(fileURLWithPath: "/path/to/track4.mp3")
        ),
        LibraryTrack(
            id: UUID(),
            name: "Jazz Cafe",
            artist: "Smooth Keys",
            album: "Coffee House",
            genre: "Jazz",
            duration: 280,
            createdAt: Date().addingTimeInterval(-345600),
            isFavorite: false,
            playCount: 32,
            filePath: URL(fileURLWithPath: "/path/to/track5.mp3")
        ),
        LibraryTrack(
            id: UUID(),
            name: "Pop Anthem",
            artist: "Chart Topper",
            album: "Summer Hits",
            genre: "Pop",
            duration: 205,
            createdAt: Date().addingTimeInterval(-432000),
            isFavorite: false,
            playCount: 203,
            filePath: URL(fileURLWithPath: "/path/to/track6.mp3")
        )
    ]
    
    enum ViewMode: String, CaseIterable {
        case list = "List"
        case grid = "Grid"
    }
    
    enum SortOrder: String, CaseIterable {
        case name = "Name"
        case dateAdded = "Date Added"
        case duration = "Duration"
        case playCount = "Play Count"
        case genre = "Genre"
    }
    
    var filteredTracks: [LibraryTrack] {
        var result = tracks
        
        // Search filter
        if !searchText.isEmpty {
            result = result.filter { track in
                track.name.localizedCaseInsensitiveContains(searchText) ||
                track.artist.localizedCaseInsensitiveContains(searchText) ||
                track.album.localizedCaseInsensitiveContains(searchText)
            }
        }
        
        // Favorites filter
        if showOnlyFavorites {
            result = result.filter { $0.isFavorite }
        }
        
        // Genre filter
        if let genre = selectedGenre, genre != "All" {
            result = result.filter { $0.genre == genre }
        }
        
        // Sort
        result.sort { track1, track2 in
            let comparison: Bool
            switch sortOrder {
            case .name:
                comparison = track1.name < track2.name
            case .dateAdded:
                comparison = track1.createdAt > track2.createdAt
            case .duration:
                comparison = track1.duration < track2.duration
            case .playCount:
                comparison = track1.playCount > track2.playCount
            case .genre:
                comparison = track1.genre < track2.genre
            }
            return isAscending ? !comparison : comparison
        }
        
        return result
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Toolbar
            HStack(spacing: 15) {
                // Search
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.secondary)
                    
                    TextField("Search tracks...", text: $searchText)
                        .textFieldStyle(.plain)
                    
                    if !searchText.isEmpty {
                        Button(action: { searchText = "" }) {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundColor(.secondary)
                        }
                        .buttonStyle(.borderless)
                    }
                }
                .padding(8)
                .background(Color(white: 0.15))
                .cornerRadius(8)
                .frame(minWidth: 300)
                
                Divider()
                    .frame(height: 20)
                
                // Genre filter
                Picker("Genre", selection: $selectedGenre) {
                    ForEach(genres, id: \.self) { genre in
                        Text(genre).tag(genre as String?)
                    }
                }
                .pickerStyle(.menu)
                .frame(width: 150)
                
                // Favorites toggle
                Toggle(isOn: $showOnlyFavorites) {
                    HStack(spacing: 5) {
                        Image(systemName: "heart.fill")
                        Text("Favorites")
                    }
                }
                .toggleStyle(.button)
                
                Spacer()
                
                // Sort
                Menu {
                    Picker("Sort By", selection: $sortOrder) {
                        ForEach(SortOrder.allCases, id: \.self) { order in
                            Label(order.rawValue, systemImage: sortOrder == order ? "checkmark" : "")
                                .tag(order)
                        }
                    }
                    
                    Divider()
                    
                    Toggle(isOn: $isAscending) {
                        Label(isAscending ? "Descending" : "Ascending", systemImage: "arrow.up.arrow.down")
                    }
                } label: {
                    HStack(spacing: 5) {
                        Image(systemName: "arrow.up.arrow.down")
                        Text("Sort")
                    }
                }
                .menuStyle(.borderlessButton)
                
                // View mode
                Picker("View", selection: $viewMode) {
                    ForEach(ViewMode.allCases, id: \.self) { mode in
                        Image(systemName: mode == .list ? "list.bullet" : "square.grid.2x2")
                            .tag(mode)
                    }
                }
                .pickerStyle(.segmented)
                .frame(width: 100)
                
                Divider()
                    .frame(height: 20)
                
                // Import
                Button(action: importTracks) {
                    HStack {
                        Image(systemName: "plus")
                        Text("Import")
                    }
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
            .background(Color(white: 0.12))
            
            // Info bar
            HStack {
                Text("\(filteredTracks.count) tracks")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                if !selectedTracks.isEmpty {
                    Text("(\(selectedTracks.count) selected)")
                        .font(.caption)
                        .foregroundColor(.blue)
                }
                
                Spacer()
                
                if let genre = selectedGenre, genre != "All" {
                    Text("Genre: \(genre)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 2)
                        .background(Color(white: 0.2))
                        .cornerRadius(4)
                }
                
                if showOnlyFavorites {
                    Text("Favorites only")
                        .font(.caption)
                        .foregroundColor(.red)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 2)
                        .background(Color.red.opacity(0.1))
                        .cornerRadius(4)
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 8)
            .background(Color(white: 0.1))
            
            // Track list/grid
            if filteredTracks.isEmpty {
                VStack(spacing: 20) {
                    Image(systemName: "music.note.list")
                        .font(.system(size: 60))
                        .foregroundColor(.secondary)
                    
                    Text("No tracks found")
                        .font(.title2)
                        .foregroundColor(.secondary)
                    
                    Text("Try adjusting your search or filters")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    Button(action: {
                        searchText = ""
                        showOnlyFavorites = false
                        selectedGenre = nil
                    }) {
                        Text("Clear filters")
                    }
                    .buttonStyle(.bordered)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                switch viewMode {
                case .list:
                    Table(filteredTracks, selection: $selectedTracks) {
                        TableColumn("Name") { track in
                            HStack(spacing: 10) {
                                Button(action: { playTrack(track) }) {
                                    Image(systemName: "play.circle.fill")
                                        .font(.title2)
                                }
                                .buttonStyle(.borderless)
                                
                                VStack(alignment: .leading) {
                                    Text(track.name)
                                        .font(.headline)
                                    Text(track.artist)
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                            }
                        }
                        .width(min: 200, ideal: 250)
                        
                        TableColumn("Album", value: \.album)
                            .width(ideal: 150)
                        
                        TableColumn("Genre") { track in
                            Text(track.genre)
                                .font(.caption)
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .background(Color.blue.opacity(0.2))
                                .cornerRadius(4)
                        }
                        .width(ideal: 100)
                        
                        TableColumn("Duration") { track in
                            Text(formatDuration(track.duration))
                        }
                        .width(ideal: 80)
                        
                        TableColumn("Plays") { track in
                            HStack(spacing: 5) {
                                Image(systemName: "play.fill")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                Text("\(track.playCount)")
                            }
                        }
                        .width(ideal: 80)
                        
                        TableColumn("Date Added") { track in
                            Text(formatDate(track.createdAt))
                        }
                        .width(ideal: 120)
                        
                        TableColumn("Favorite") { track in
                            Button(action: { toggleFavorite(track) }) {
                                Image(systemName: track.isFavorite ? "heart.fill" : "heart")
                                    .foregroundColor(track.isFavorite ? .red : .secondary)
                            }
                            .buttonStyle(.borderless)
                        }
                        .width(ideal: 60)
                    }
                    
                case .grid:
                    ScrollView {
                        LazyVGrid(columns: [
                            GridItem(.flexible(minimum: 200, maximum: 300)),
                            GridItem(.flexible(minimum: 200, maximum: 300)),
                            GridItem(.flexible(minimum: 200, maximum: 300))
                        ], spacing: 20) {
                            ForEach(filteredTracks, id: \.id) { track in
                                TrackCard(track: track)
                                    .onTapGesture {
                                        if selectedTracks.contains(track.id) {
                                            selectedTracks.remove(track.id)
                                        } else {
                                            selectedTracks.insert(track.id)
                                        }
                                    }
                            }
                        }
                        .padding()
                    }
                }
            }
        }
        .navigationTitle("Track Library")
        .toolbar {
            ToolbarItem(placement: .automatic) {
                if !selectedTracks.isEmpty {
                    Button(action: {}) {
                        Text("Export Selected")
                    }
                }
            }
        }
    }
    
    private func formatDuration(_ seconds: Int) -> String {
        let minutes = seconds / 60
        let remainingSeconds = seconds % 60
        return String(format: "%d:%02d", minutes, remainingSeconds)
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        return formatter.string(from: date)
    }
    
    private func importTracks() {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.audio]
        panel.allowsMultipleSelection = true
        panel.canChooseDirectories = false
        
        if panel.runModal() == .OK {
            for url in panel.urls {
                let newTrack = LibraryTrack(
                    id: UUID(),
                    name: url.deletingPathExtension().lastPathComponent,
                    artist: "Unknown Artist",
                    album: "Unknown Album",
                    genre: "Electronic",
                    duration: 180,
                    createdAt: Date(),
                    isFavorite: false,
                    playCount: 0,
                    filePath: url
                )
                tracks.append(newTrack)
            }
        }
    }
    
    private func playTrack(_ track: LibraryTrack) {
        // Implementation would play the track
        print("Playing: \(track.name)")
    }
    
    private func toggleFavorite(_ track: LibraryTrack) {
        if let index = tracks.firstIndex(where: { $0.id == track.id }) {
            tracks[index].isFavorite.toggle()
        }
    }
}

struct LibraryTrack: Identifiable {
    let id: UUID
    var name: String
    var artist: String
    var album: String
    var genre: String
    var duration: Int
    var createdAt: Date
    var isFavorite: Bool
    var playCount: Int
    var filePath: URL
}

struct TrackCard: View {
    let track: LibraryTrack
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            // Album art placeholder
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .fill(
                        LinearGradient(
                            gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.purple.opacity(0.6)]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                
                Image(systemName: "music.note")
                    .font(.system(size: 40))
                    .foregroundColor(.white.opacity(0.8))
            }
            .frame(height: 150)
            
            // Track info
            VStack(alignment: .leading, spacing: 5) {
                Text(track.name)
                    .font(.headline)
                    .lineLimit(1)
                
                Text(track.artist)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .lineLimit(1)
                
                HStack {
                    Text(track.genre)
                        .font(.caption)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.blue.opacity(0.2))
                        .cornerRadius(4)
                    
                    Spacer()
                    
                    Text(formatDuration(track.duration))
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                HStack {
                    Image(systemName: "play.fill")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                    
                    Text("\(track.playCount) plays")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                    
                    Spacer()
                    
                    if track.isFavorite {
                        Image(systemName: "heart.fill")
                            .font(.caption2)
                            .foregroundColor(.red)
                    }
                }
            }
        }
        .padding()
        .background(Color(white: 0.12))
        .cornerRadius(12)
    }
    
    private func formatDuration(_ seconds: Int) -> String {
        let minutes = seconds / 60
        let remainingSeconds = seconds % 60
        return String(format: "%d:%02d", minutes, remainingSeconds)
    }
}

struct TrackLibraryView_Previews: PreviewProvider {
    static var previews: some View {
        TrackLibraryView()
            .preferredColorScheme(.dark)
    }
}