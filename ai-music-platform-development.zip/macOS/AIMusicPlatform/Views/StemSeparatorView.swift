//
//  StemSeparatorView.swift
//  AIMusicPlatform
//
//  Created by AI Assistant on 2024.
//

import SwiftUI
import AVFoundation

struct StemSeparatorView: View {
    @State private var isDragging = false
    @State private var isProcessing = false
    @State private var separationProgress: Double = 0
    @State private var selectedFile: URL?
    @State private var separatedStems: [Stem] = []
    @State private var showProcessingDetails = false
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                VStack(alignment: .leading) {
                    Text("Stem Separator")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                    Text("Isolate vocals, drums, bass, and instruments from any audio track")
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                Button(action: { showProcessingDetails.toggle() }) {
                    HStack {
                        Image(systemName: "info.circle")
                        Text("How it works")
                    }
                }
                .buttonStyle(.bordered)
            }
            .padding()
            .background(Color(white: 0.12))
            
            Divider()
            
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    // Upload Zone
                    VStack(spacing: 15) {
                        Text("Upload Audio File")
                            .font(.headline)
                        
                        Button(action: selectFile) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(isDragging ? Color.purple : Color.gray, lineWidth: 2)
                                    .background(
                                        RoundedRectangle(cornerRadius: 20)
                                            .fill(isDragging ? Color.purple.opacity(0.1) : Color(white: 0.15))
                                    )
                                    .frame(height: 200)
                                
                                VStack(spacing: 15) {
                                    Image(systemName: "waveform.and.magnifyingglass")
                                        .font(.system(size: 50))
                                        .foregroundColor(.purple)
                                    
                                    Text(isDragging ? "Drop audio file here" : "Click to upload or drag and drop")
                                        .font(.headline)
                                    
                                    Text("Supports MP3, WAV, AIFF, FLAC (Max 100MB)")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                            }
                        }
                        .buttonStyle(.borderless)
                        .onDrop(of: [.fileURL], delegate: DropViewDelegate(isDragging: $isDragging, fileSelected: $selectedFile))
                        
                        if let file = selectedFile {
                            HStack {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundColor(.green)
                                Text(file.lastPathComponent)
                                    .font(.body)
                                Spacer()
                                Button(action: { selectedFile = nil }) {
                                    Image(systemName: "xmark.circle.fill")
                                        .foregroundColor(.secondary)
                                }
                                .buttonStyle(.borderless)
                            }
                            .padding()
                            .background(Color(white: 0.15))
                            .cornerRadius(10)
                        }
                    }
                    
                    // Separation Options
                    VStack(alignment: .leading, spacing: 15) {
                        Text("Separation Options")
                            .font(.headline)
                        
                        HStack(spacing: 20) {
                            VStack(alignment: .leading, spacing: 5) {
                                Text("Stems to Extract:")
                                    .font(.subheadline)
                                
                                HStack(spacing: 10) {
                                    StemToggle(name: "Vocals", isOn: .constant(true))
                                    StemToggle(name: "Drums", isOn: .constant(true))
                                    StemToggle(name: "Bass", isOn: .constant(true))
                                    StemToggle(name: "Instruments", isOn: .constant(true))
                                }
                            }
                            
                            Spacer()
                            
                            VStack(alignment: .leading, spacing: 5) {
                                Text("Quality Mode:")
                                    .font(.subheadline)
                                
                                Picker("Quality", selection: .constant(1)) {
                                    Text("Fast (Lower Quality)").tag(0)
                                    Text("Standard").tag(1)
                                    Text("High Quality").tag(2)
                                }
                                .pickerStyle(.segmented)
                                .frame(width: 280)
                            }
                        }
                    }
                    .padding()
                    .background(Color(white: 0.12))
                    .cornerRadius(12)
                    
                    // Process Button
                    Button(action: startSeparation) {
                        HStack {
                            if isProcessing {
                                ProgressView()
                                    .progressViewStyle(.circular)
                            } else {
                                Image(systemName: "scissors")
                            }
                            
                            Text(isProcessing ? "Separating Stems..." : "Start Separation")
                                .font(.headline)
                                .fontWeight(.bold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(
                            LinearGradient(
                                gradient: Gradient(colors: [Color.purple, Color.blue]),
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .cornerRadius(12)
                        .foregroundColor(.white)
                    }
                    .buttonStyle(.borderless)
                    .disabled(selectedFile == nil || isProcessing)
                    
                    // Progress
                    if isProcessing {
                        VStack(spacing: 10) {
                            ProgressView(value: separationProgress, total: 1.0)
                                .progressViewStyle(.linear)
                            
                            HStack {
                                Text("Processing... \(Int(separationProgress * 100))%")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                
                                Spacer()
                                
                                Text("Analyzing audio frequencies and applying AI separation")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                        .padding(.vertical)
                    }
                    
                    // Results
                    if !separatedStems.isEmpty {
                        VStack(alignment: .leading, spacing: 15) {
                            HStack {
                                Text("Separated Stems")
                                    .font(.headline)
                                
                                Spacer()
                                
                                Button(action: {}) {
                                    HStack {
                                        Image(systemName: "square.and.arrow.down")
                                        Text("Export All")
                                    }
                                }
                                .buttonStyle(.bordered)
                            }
                            
                            ForEach(separatedStems) { stem in
                                StemRow(stem: stem)
                            }
                        }
                        
                        // Processing Details
                        if showProcessingDetails {
                            VStack(alignment: .leading, spacing: 10) {
                                Text("Processing Summary")
                                    .font(.headline)
                                
                                HStack(spacing: 20) {
                                    ProcessingStat(label: "Original File", value: selectedFile?.lastPathComponent ?? "N/A")
                                    ProcessingStat(label: "Duration", value: "3:45")
                                    ProcessingStat(label: "Sample Rate", value: "44.1 kHz")
                                    ProcessingStat(label: "Processing Time", value: "42 seconds")
                                }
                                
                                Text("AI separation completed using deep learning model. Each stem has been normalized and optimized for quality.")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                            .padding()
                            .background(Color(white: 0.12))
                            .cornerRadius(12)
                        }
                    }
                    
                    Spacer()
                }
                .padding()
            }
        }
    }
    
    private func selectFile() {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.audio]
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = false
        
        if panel.runModal() == .OK, let url = panel.url {
            selectedFile = url
        }
    }
    
    private func startSeparation() {
        guard selectedFile != nil else { return }
        
        isProcessing = true
        separationProgress = 0
        
        // Simulate AI processing
        Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { timer in
            separationProgress += 0.015
            
            if separationProgress >= 1.0 {
                timer.invalidate()
                isProcessing = false
                
                // Create separated stems
                separatedStems = [
                    Stem(id: UUID(), name: "Vocals", color: .green, waveformData: generateWaveformData()),
                    Stem(id: UUID(), name: "Drums", color: .orange, waveformData: generateWaveformData()),
                    Stem(id: UUID(), name: "Bass", color: .blue, waveformData: generateWaveformData()),
                    Stem(id: UUID(), name: "Instruments", color: .purple, waveformData: generateWaveformData())
                ]
            }
        }
    }
    
    private func generateWaveformData() -> [Double] {
        return (0..<100).map { _ in Double.random(in: 0.2...0.8) }
    }
}

struct Stem: Identifiable {
    let id: UUID
    let name: String
    let color: Color
    let waveformData: [Double]
    var isMuted: Bool = false
    var volume: Double = 1.0
}

struct StemToggle: View {
    let name: String
    @Binding var isOn: Bool
    
    var body: some View {
        Toggle(isOn: $isOn) {
            Text(name)
                .font(.caption)
        }
        .toggleStyle(.switch)
    }
}

struct StemRow: View {
    let stem: Stem
    @State private var isPlaying = false
    @State private var volume: Double = 0.8
    @State private var isMuted = false
    
    var body: some View {
        HStack(spacing: 15) {
            // Play/Pause
            Button(action: { isPlaying.toggle() }) {
                Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                    .font(.title2)
                    .frame(width: 40, height: 40)
                    .background(stem.color.opacity(0.2))
                    .cornerRadius(10)
            }
            .buttonStyle(.borderless)
            
            // Stem Info
            VStack(alignment: .leading, spacing: 5) {
                Text(stem.name)
                    .font(.headline)
                
                HStack {
                    Text("Stem")
                        .font(.caption)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(stem.color.opacity(0.2))
                        .cornerRadius(4)
                    
                    Text("3:45")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            .frame(width: 120, alignment: .leading)
            
            // Volume Control
            VStack(alignment: .leading, spacing: 2) {
                Text("Volume")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                HStack {
                    Button(action: { isMuted.toggle() }) {
                        Image(systemName: isMuted ? "speaker.slash.fill" : "speaker.fill")
                            .foregroundColor(isMuted ? .red : .secondary)
                    }
                    .buttonStyle(.borderless)
                    
                    Slider(value: $volume, in: 0...1)
                        .frame(width: 100)
                }
            }
            .frame(width: 180)
            
            // Waveform
            HStack(spacing: 2) {
                ForEach(Array(stem.waveformData.enumerated()), id: \.offset) { _, value in
                    RoundedRectangle(cornerRadius: 1)
                        .fill(stem.color)
                        .frame(width: 2, height: CGFloat(value) * 40)
                }
            }
            .frame(height: 40)
            .background(stem.color.opacity(0.1))
            .cornerRadius(5)
            
            // Actions
            HStack(spacing: 10) {
                Button(action: {}) {
                    Image(systemName: "square.and.arrow.down")
                }
                .buttonStyle(.borderless)
                .help("Download Stem")
                
                Button(action: {}) {
                    Image(systemName: "eye")
                }
                .buttonStyle(.borderless)
                .help("Solo Stem")
                
                Button(action: {}) {
                    Image(systemName: "ellipsis.circle")
                }
                .buttonStyle(.borderless)
                .help("More Options")
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color(white: 0.12))
        )
    }
}

struct ProcessingStat: View {
    let label: String
    let value: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(label)
                .font(.caption)
                .foregroundColor(.secondary)
            
            Text(value)
                .font(.subheadline)
                .fontWeight(.medium)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct DropViewDelegate: DropDelegate {
    @Binding var isDragging: Bool
    @Binding var fileSelected: URL?
    
    func performDrop(info: DropInfo) -> Bool {
        isDragging = false
        
        guard let item = info.itemProviders(for: [.fileURL]).first else { return false }
        
        item.loadItem(forTypeIdentifier: "public.file-url", options: nil) { data, error in
            if let data = data as? Data, let url = URL(dataRepresentation: data, relativeTo: nil) {
                DispatchQueue.main.async {
                    fileSelected = url
                }
            }
        }
        
        return true
    }
    
    func dropEntered(info: DropInfo) {
        isDragging = true
    }
    
    func dropExited(info: DropInfo) {
        isDragging = false
    }
}

struct StemSeparatorView_Previews: PreviewProvider {
    static var previews: some View {
        StemSeparatorView()
            .preferredColorScheme(.dark)
    }
}