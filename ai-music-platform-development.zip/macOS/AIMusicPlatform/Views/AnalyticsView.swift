//
//  AnalyticsView.swift
//  AIMusicPlatform
//
//  Created by AI Assistant on 2024.
//

import SwiftUI
import Charts

struct AnalyticsView: View {
    @State private var selectedTimeRange = "Week"
    @State private var selectedMetric = "Streams"
    @State private var showDetailedView = false
    
    let timeRanges = ["Day", "Week", "Month", "Year"]
    let metrics = ["Streams", "Revenue", "Listeners", "Downloads"]
    
    // Sample data
    let streamsData: [(period: String, value: Int)] = [
        ("Mon", 1250), ("Tue", 1420), ("Wed", 1680), ("Thu", 1890),
        ("Fri", 2150), ("Sat", 2340), ("Sun", 1920)
    ]
    
    let revenueData: [(period: String, value: Double)] = [
        ("Mon", 125.50), ("Tue", 142.30), ("Wed", 168.75), ("Thu", 189.20),
        ("Fri", 215.80), ("Sat", 234.10), ("Sun", 192.40)
    ]
    
    let listenersData: [(period: String, value: Int)] = [
        ("Mon", 450), ("Tue", 520), ("Wed", 610), ("Thu", 680),
        ("Fri", 750), ("Sat", 820), ("Sun", 690)
    ]
    
    let genreDistribution: [(genre: String, percentage: Double)] = [
        ("Synthwave", 35), ("Lo-fi", 25), ("Electronic", 20),
        ("Pop", 12), ("Other", 8)
    ]
    
    let topTracks: [TrackPerformance] = [
        TrackPerformance(id: UUID(), name: "Neon Dreams", streams: 5234, revenue: 523.40, listeners: 1234),
        TrackPerformance(id: UUID(), name: "Midnight Drive", streams: 4123, revenue: 412.30, listeners: 987),
        TrackPerformance(id: UUID(), name: "Electric Pulse", streams: 3456, revenue: 345.60, listeners: 876),
        TrackPerformance(id: UUID(), name: "Digital Dreams", streams: 2890, revenue: 289.00, listeners: 765),
        TrackPerformance(id: UUID(), name: "Synthwave Sunset", streams: 2345, revenue: 234.50, listeners: 654)
    ]
    
    let geographicData: [RegionData] = [
        RegionData(id: UUID(), name: "United States", streams: 4521, percentage: 35),
        RegionData(id: UUID(), name: "United Kingdom", streams: 2341, percentage: 18),
        RegionData(id: UUID(), name: "Germany", streams: 1890, percentage: 15),
        RegionData(id: UUID(), name: "France", streams: 1456, percentage: 11),
        RegionData(id: UUID(), name: "Japan", streams: 1234, percentage: 10),
        RegionData(id: UUID(), name: "Other", streams: 1320, percentage: 10)
    ]
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // Header
                HStack {
                    VStack(alignment: .leading) {
                        Text("Analytics Dashboard")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                        Text("Track your music performance and audience engagement")
                            .foregroundColor(.secondary)
                    }
                    
                    Spacer()
                    
                    HStack(spacing: 15) {
                        Picker("Time Range", selection: $selectedTimeRange) {
                            ForEach(timeRanges, id: \.self) { range in
                                Text(range).tag(range)
                            }
                        }
                        .pickerStyle(.segmented)
                        
                        Picker("Metric", selection: $selectedMetric) {
                            ForEach(metrics, id: \.self) { metric in
                                Text(metric).tag(metric)
                            }
                        }
                        .pickerStyle(.menu)
                        .frame(width: 120)
                        
                        Button(action: { showDetailedView.toggle() }) {
                            HStack {
                                Image(systemName: "chart.bar.doc.horizontal")
                                Text("Detailed Report")
                            }
                        }
                        .buttonStyle(.bordered)
                    }
                }
                .padding(.bottom, 10)
                
                // Stats Cards
                LazyVGrid(columns: [
                    GridItem(.flexible()),
                    GridItem(.flexible()),
                    GridItem(.flexible()),
                    GridItem(.flexible())
                ], spacing: 20) {
                    StatCard(
                        title: "Total Streams",
                        value: "12,650",
                        change: "+12.5%",
                        icon: "play.circle.fill",
                        color: .blue
                    )
                    
                    StatCard(
                        title: "Revenue",
                        value: "$1,267.50",
                        change: "+8.2%",
                        icon: "dollarsign.circle.fill",
                        color: .green
                    )
                    
                    StatCard(
                        title: "Listeners",
                        value: "3,420",
                        change: "+15.3%",
                        icon: "person.3.fill",
                        color: .purple
                    )
                    
                    StatCard(
                        title: "Downloads",
                        value: "892",
                        change: "+23.1%",
                        icon: "square.and.arrow.down.fill",
                        color: .orange
                    )
                }
                
                // Charts Section
                HStack(spacing: 20) {
                    // Main Chart
                    VStack(alignment: .leading) {
                        Text("Performance Overview")
                            .font(.headline)
                            .padding(.bottom, 5)
                        
                        Chart {
                            ForEach(streamsData, id: \.period) { period, value in
                                BarMark(
                                    x: .value("Period", period),
                                    y: .value("Streams", value)
                                )
                                .foregroundStyle(.linearGradient(
                                    colors: [Color.blue, Color.blue.opacity(0.6)],
                                    startPoint: .top,
                                    endPoint: .bottom
                                ))
                                .cornerRadius(5)
                            }
                        }
                        .frame(height: 250)
                        .chartYAxis {
                            AxisMarks(position: .leading)
                        }
                    }
                    .padding()
                    .background(Color(white: 0.12))
                    .cornerRadius(12)
                    
                    // Genre Distribution
                    VStack(alignment: .leading) {
                        Text("Genre Distribution")
                            .font(.headline)
                            .padding(.bottom, 5)
                        
                        Chart(genreDistribution, id: \.genre) { genre, percentage in
                            SectorMark(
                                angle: .value("Percentage", percentage),
                                innerRadius: .ratio(0.6),
                                angularInset: 2
                            )
                            .foregroundStyle(by: .value("Genre", genre))
                        }
                        .frame(height: 200)
                        .chartLegend(position: .bottom, alignment: .center)
                        
                        // Genre breakdown list
                        VStack(alignment: .leading, spacing: 8) {
                            ForEach(genreDistribution, id: \.genre) { genre, percentage in
                                HStack {
                                    Circle()
                                        .fill(getGenreColor(genre))
                                        .frame(width: 10, height: 10)
                                    
                                    Text(genre)
                                        .font(.caption)
                                    
                                    Spacer()
                                    
                                    Text("\(percentage)%")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                            }
                        }
                    }
                    .padding()
                    .background(Color(white: 0.12))
                    .cornerRadius(12)
                }
                
                // Geographic Distribution
                VStack(alignment: .leading) {
                    Text("Geographic Distribution")
                        .font(.headline)
                        .padding(.bottom, 5)
                    
                    HStack(spacing: 20) {
                        // Map placeholder
                        ZStack {
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color(white: 0.15))
                            
                            VStack {
                                Image(systemName: "globe")
                                    .font(.system(size: 60))
                                    .foregroundColor(.blue.opacity(0.6))
                                
                                Text("World Map")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                            }
                        }
                        .frame(width: 300, height: 200)
                        
                        // Region list
                        VStack(alignment: .leading, spacing: 10) {
                            ForEach(geographicData) { region in
                                HStack {
                                    Text(region.name)
                                        .font(.caption)
                                        .frame(width: 120, alignment: .leading)
                                    
                                    GeometryReader { geometry in
                                        ZStack(alignment: .leading) {
                                            RoundedRectangle(cornerRadius: 5)
                                                .fill(Color.gray.opacity(0.3))
                                            
                                            RoundedRectangle(cornerRadius: 5)
                                                .fill(getRegionColor(region.name))
                                                .frame(width: geometry.size.width * CGFloat(region.percentage) / 100)
                                        }
                                    }
                                    .frame(height: 20)
                                    
                                    Text("\(region.streams)")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                        .frame(width: 60, alignment: .trailing)
                                }
                            }
                        }
                    }
                }
                .padding()
                .background(Color(white: 0.12))
                .cornerRadius(12)
                
                // Top Performing Tracks
                VStack(alignment: .leading, spacing: 15) {
                    HStack {
                        Text("Top Performing Tracks")
                            .font(.headline)
                        
                        Spacer()
                        
                        Button(action: {}) {
                            Text("View All")
                        }
                    }
                    
                    Table(topTracks) {
                        TableColumn("Rank") { track in
                            if let index = topTracks.firstIndex(where: { $0.id == track.id }) {
                                Text("\(index + 1)")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                    .frame(width: 30)
                            }
                        }
                        .width(50)
                        
                        TableColumn("Track Name") { track in
                            HStack(spacing: 10) {
                                Button(action: {}) {
                                    Image(systemName: "play.circle.fill")
                                }
                                .buttonStyle(.borderless)
                                
                                Text(track.name)
                                    .font(.subheadline)
                            }
                        }
                        .width(min: 200)
                        
                        TableColumn("Streams") { track in
                            HStack(spacing: 5) {
                                Image(systemName: "play.fill")
                                    .font(.caption2)
                                    .foregroundColor(.secondary)
                                Text("\(track.streams)")
                            }
                        }
                        .width(100)
                        
                        TableColumn("Revenue") { track in
                            Text(String(format: "$%.2f", track.revenue))
                        }
                        .width(100)
                        
                        TableColumn("Listeners") { track in
                            HStack(spacing: 5) {
                                Image(systemName: "person.fill")
                                    .font(.caption2)
                                    .foregroundColor(.secondary)
                                Text("\(track.listeners)")
                            }
                        }
                        .width(100)
                        
                        TableColumn("Performance") { track in
                            HStack {
                                Image(systemName: "arrow.up")
                                    .foregroundColor(.green)
                                Text("+12%")
                                    .font(.caption)
                                    .foregroundColor(.green)
                            }
                        }
                        .width(100)
                    }
                }
                .padding()
                .background(Color(white: 0.12))
                .cornerRadius(12)
                
                Spacer()
            }
            .padding()
        }
    }
    
    private func getGenreColor(_ genre: String) -> Color {
        switch genre {
        case "Synthwave": return .purple
        case "Lo-fi": return .blue
        case "Electronic": return .green
        case "Pop": return .pink
        case "Other": return .gray
        default: return .secondary
        }
    }
    
    private func getRegionColor(_ region: String) -> Color {
        switch region {
        case "United States": return .blue
        case "United Kingdom": return .purple
        case "Germany": return .green
        case "France": return .pink
        case "Japan": return .orange
        case "Other": return .gray
        default: return .secondary
        }
    }
}

struct TrackPerformance: Identifiable {
    let id: UUID
    let name: String
    let streams: Int
    let revenue: Double
    let listeners: Int
}

struct RegionData: Identifiable {
    let id: UUID
    let name: String
    let streams: Int
    let percentage: Int
}

struct AnalyticsView_Previews: PreviewProvider {
    static var previews: some View {
        AnalyticsView()
            .preferredColorScheme(.dark)
    }
}