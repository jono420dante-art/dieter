//
//  MusicGeneratorView.swift
//  AIMusicPlatform
//
//  Created by AI Assistant on 2024.
//

import SwiftUI
import AVFoundation
import AudioKit

struct MusicGeneratorView: View {
    @State private var prompt: String = ""
    @State private var genre: String = "Synthwave"
    @State private var mood: String = "Energetic"
    @State private var duration: Double = 30
    @State private var bpm: Double = 120
    @State private var isGenerating = false
    @State private var generatedTracks: [GeneratedTrack] = []
    @State private var selectedTrack: GeneratedTrack?
    @State private var showAdvancedSettings = false
    @State private var generationProgress: Double = 0
    
    let genres = ["Synthwave", "Lo-fi", "Electronic", "Pop", "Jazz", "Rock", "Hip-Hop", "Classical"]
    let moods = ["Energetic", "Calm", "Happy", "Sad", "Mysterious", "Romantic", "Epic"]
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                VStack(alignment: .leading) {
                    Text("AI Music Generator")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                    Text("Create original music from text prompts using AI")
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                Button(action: { showAdvancedSettings.toggle() }) {
                    HStack {
                        Image(systemName: "slider.horizontal.3")
                        Text("Advanced")
                    }
                }
                .buttonStyle(.bordered)
            }
            .padding()
            .background(Color(white: 0.12))
            
            Divider()
            
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    // Prompt Input
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Describe your music:")
                            .font(.headline)
                        
                        TextEditor(text: $prompt)
                            .font(.body)
                            .frame(minHeight: 100)
                            .padding(8)
                            .background(Color(white: 0.15))
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color(white: 0.3), lineWidth: 1)
                            )
                        
                        Text("Example: 'Upbeat synthwave track with retro vibes, catchy melody, and driving bassline'")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    
                    // Genre & Mood
                    HStack(spacing: 20) {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Genre:")
                                .font(.headline)
                            
                            Picker("Genre", selection: $genre) {
                                ForEach(genres, id: \.self) { genre in
                                    Text(genre).tag(genre)
                                }
                            }
                            .pickerStyle(.menu)
                            .frame(maxWidth: .infinity)
                        }
                        
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Mood:")
                                .font(.headline)
                            
                            Picker("Mood", selection: $mood) {
                                ForEach(moods, id: \.self) { mood in
                                    Text(mood).tag(mood)
                                }
                            }
                            .pickerStyle(.menu)
                            .frame(maxWidth: .infinity)
                        }
                    }
                    
                    // Duration & BPM
                    HStack(spacing: 20) {
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Text("Duration:")
                                    .font(.headline)
                                Spacer()
                                Text("\(Int(duration)) seconds")
                                    .foregroundColor(.secondary)
                            }
                            
                            Slider(value: $duration, in: 15...180, step: 5)
                        }
                        
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Text("Tempo (BPM):")
                                    .font(.headline)
                                Spacer()
                                Text("\(Int(bpm)) BPM")
                                    .foregroundColor(.secondary)
                            }
                            
                            Slider(value: $bpm, in: 60...180, step: 1)
                        }
                    }
                    
                    // Advanced Settings
                    if showAdvancedSettings {
                        VStack(alignment: .leading, spacing: 15) {
                            Text("Advanced Settings")
                                .font(.headline)
                            
                            HStack(spacing: 20) {
                                VStack(alignment: .leading, spacing: 5) {
                                    Text("Instrumentation:")
                                        .font(.subheadline)
                                    
                                    ScrollView(.horizontal, showsIndicators: false) {
                                        HStack(spacing: 8) {
                                            ForEach(["Synth", "Piano", "Guitar", "Bass", "Drums", "Strings", "Vocals"], id: \.self) { instrument in
                                                Text(instrument)
                                                    .padding(.horizontal, 10)
                                                    .padding(.vertical, 5)
                                                    .background(Color.blue.opacity(0.2))
                                                    .cornerRadius(20)
                                            }
                                        }
                                    }
                                }
                            }
                            
                            Toggle("Include Vocals", isOn: .constant(true))
                            Toggle("Generate Lyrics", isOn: .constant(false))
                        }
                        .padding()
                        .background(Color(white: 0.12))
                        .cornerRadius(12)
                    }
                    
                    // Generate Button
                    Button(action: generateMusic) {
                        HStack {
                            if isGenerating {
                                ProgressView()
                                    .progressViewStyle(.circular)
                            } else {
                                Image(systemName: "wand.and.stars")
                            }
                            
                            Text(isGenerating ? "Generating..." : "Generate Music")
                                .font(.headline)
                                .fontWeight(.bold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(
                            LinearGradient(
                                gradient: Gradient(colors: [Color.purple, Color.blue]),
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .cornerRadius(12)
                        .foregroundColor(.white)
                    }
                    .buttonStyle(.borderless)
                    .disabled(prompt.isEmpty || isGenerating)
                    
                    // Progress Bar
                    if isGenerating {
                        VStack(spacing: 5) {
                            ProgressView(value: generationProgress, total: 1.0)
                                .progressViewStyle(.linear)
                            
                            Text("AI is composing your music... \(Int(generationProgress * 100))%")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        .padding(.vertical)
                    }
                    
                    // Generated Tracks
                    if !generatedTracks.isEmpty {
                        VStack(alignment: .leading, spacing: 15) {
                            HStack {
                                Text("Generated Tracks")
                                    .font(.headline)
                                
                                Spacer()
                                
                                Button(action: {}) {
                                    Text("Export All")
                                }
                            }
                            
                            ForEach(generatedTracks) { track in
                                TrackRow(track: track, isSelected: selectedTrack == track)
                                    .onTapGesture {
                                        selectedTrack = track
                                    }
                            }
                        }
                    }
                }
                .padding()
            }
        }
    }
    
    func generateMusic() {
        isGenerating = true
        generationProgress = 0
        
        // Simulate AI generation progress
        Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { timer in
            generationProgress += 0.02
            
            if generationProgress >= 1.0 {
                timer.invalidate()
                isGenerating = false
                
                // Create a new generated track
                let newTrack = GeneratedTrack(
                    id: UUID(),
                    name: "\(mood) \(genre) - \(generatedTracks.count + 1)",
                    duration: duration,
                    bpm: bpm,
                    genre: genre,
                    mood: mood,
                    createdAt: Date(),
                    prompt: prompt
                )
                
                generatedTracks.insert(newTrack, at: 0)
                selectedTrack = newTrack
                
                // Reset prompt for next generation
                prompt = ""
            }
        }
    }
}

struct GeneratedTrack: Identifiable, Equatable {
    let id: UUID
    let name: String
    let duration: Double
    let bpm: Double
    let genre: String
    let mood: String
    let createdAt: Date
    let prompt: String
}

struct TrackRow: View {
    let track: GeneratedTrack
    let isSelected: Bool
    @State private var isPlaying = false
    
    var body: some View {
        HStack(spacing: 15) {
            // Play/Pause Button
            Button(action: { isPlaying.toggle() }) {
                Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                    .font(.title2)
                    .frame(width: 40, height: 40)
                    .background(Color.blue.opacity(0.2))
                    .cornerRadius(10)
            }
            .buttonStyle(.borderless)
            
            // Track Info
            VStack(alignment: .leading, spacing: 5) {
                Text(track.name)
                    .font(.headline)
                
                HStack {
                    Text(track.genre)
                        .font(.caption)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.purple.opacity(0.2))
                        .cornerRadius(4)
                    
                    Text(track.mood)
                        .font(.caption)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.green.opacity(0.2))
                        .cornerRadius(4)
                    
                    Text("\(Int(track.duration))s")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    Text("\(Int(track.bpm)) BPM")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            Spacer()
            
            // Actions
            HStack(spacing: 10) {
                Button(action: {}) {
                    Image(systemName: "square.and.arrow.down")
                }
                .buttonStyle(.borderless)
                .help("Download")
                
                Button(action: {}) {
                    Image(systemName: "square.and.arrow.up")
                }
                .buttonStyle(.borderless)
                .help("Share")
                
                Button(action: {}) {
                    Image(systemName: "ellipsis.circle")
                }
                .buttonStyle(.borderless)
                .help("More Options")
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(isSelected ? Color.blue.opacity(0.15) : Color(white: 0.12))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(isSelected ? Color.blue : Color.clear, lineWidth: 2)
        )
    }
}

struct MusicGeneratorView_Previews: PreviewProvider {
    static var previews: some View {
        MusicGeneratorView()
            .preferredColorScheme(.dark)
    }
}