//
//  SettingsView.swift
//  AIMusicPlatform
//
//  Created by AI Assistant on 2024.
//

import SwiftUI
import AVFoundation

struct SettingsView: View {
    @State private var selectedTab = "General"
    @State private var audioInput: String = "Built-in Microphone"
    @State private var audioOutput: String = "Built-in Output"
    @State private var sampleRate: Double = 44100
    @State private var bufferSize: Int = 512
    @State private var theme: String = "Dark"
    @State private var autoSave: Bool = true
    @State private var notifications: Bool = true
    @State private var cloudSync: Bool = false
    @State private var analyticsOptIn: Bool = true
    @State private var showAdvancedAudio: Bool = false
    
    let tabs = ["General", "Audio", "Account", "Appearance", "Notifications", "Advanced"]
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                VStack(alignment: .leading) {
                    Text("Settings")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                    Text("Configure your preferences and account settings")
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                Button(action: {}) {
                    HStack {
                        Image(systemName: "arrow.clockwise")
                        Text("Reset to Defaults")
                    }
                }
                .buttonStyle(.bordered)
            }
            .padding()
            .background(Color(white: 0.12))
            
            Divider()
            
            HSplitView {
                // Sidebar
                List(tabs, id: \.self, selection: $selectedTab) { tab in
                    Label(tab, systemImage: getTabIcon(tab))
                        .tag(tab)
                        .listRowBackground(selectedTab == tab ? Color.blue.opacity(0.3) : Color.clear)
                }
                .listStyle(.sidebar)
                .frame(minWidth: 200, idealWidth: 250)
                
                // Content
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        switch selectedTab {
                        case "General":
                            GeneralSettingsView(autoSave: $autoSave, cloudSync: $cloudSync, theme: $theme)
                        case "Audio":
                            AudioSettingsView(
                                audioInput: $audioInput,
                                audioOutput: $audioOutput,
                                sampleRate: $sampleRate,
                                bufferSize: $bufferSize,
                                showAdvanced: $showAdvancedAudio
                            )
                        case "Account":
                            AccountSettingsView()
                        case "Appearance":
                            AppearanceSettingsView()
                        case "Notifications":
                            NotificationSettingsView(notifications: $notifications)
                        case "Advanced":
                            AdvancedSettingsView(analyticsOptIn: $analyticsOptIn)
                        default:
                            Text("Select a settings category")
                                .foregroundColor(.secondary)
                        }
                    }
                    .padding()
                }
                .frame(minWidth: 600)
            }
        }
    }
    
    private func getTabIcon(_ tab: String) -> String {
        switch tab {
        case "General": return "gearshape"
        case "Audio": return "waveform"
        case "Account": return "person.circle"
        case "Appearance": return "paintbrush"
        case "Notifications": return "bell"
        case "Advanced": return "gearshape.2"
        default: return "gearshape"
        }
    }
}

struct GeneralSettingsView: View {
    @Binding var autoSave: Bool
    @Binding var cloudSync: Bool
    @Binding var theme: String
    
    let themes = ["Dark", "Light", "System"]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("General Settings")
                .font(.headline)
            
            GroupBox {
                VStack(alignment: .leading, spacing: 15) {
                    Toggle("Auto-save projects", isOn: $autoSave)
                    
                    Toggle("Cloud sync", isOn: $cloudSync)
                    
                    Picker("Theme", selection: $theme) {
                        ForEach(themes, id: \.self) { theme in
                            Text(theme).tag(theme)
                        }
                    }
                    .pickerStyle(.segmented)
                    .frame(width: 300)
                }
                .padding()
            }
            
            GroupBox("File Management") {
                VStack(alignment: .leading, spacing: 15) {
                    HStack {
                        Text("Default save location:")
                        Spacer()
                        Button(action: {}) {
                            HStack {
                                Text("~/Music/AIMusicPlatform")
                                Image(systemName: "folder")
                            }
                        }
                        .buttonStyle(.bordered)
                    }
                    
                    HStack {
                        Text("Temporary files:")
                        Spacer()
                        Button(action: {}) {
                            Text("Clear Temporary Files")
                        }
                        .buttonStyle(.bordered)
                    }
                }
                .padding()
            }
        }
    }
}

struct AudioSettingsView: View {
    @Binding var audioInput: String
    @Binding var audioOutput: String
    @Binding var sampleRate: Double
    @Binding var bufferSize: Int
    @Binding var showAdvanced: Bool
    
    let sampleRates = [44100.0, 48000.0, 96000.0]
    let bufferSizes = [128, 256, 512, 1024, 2048]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Audio Settings")
                .font(.headline)
            
            GroupBox("Audio Devices") {
                VStack(alignment: .leading, spacing: 15) {
                    HStack {
                        Text("Input Device:")
                        Picker("", selection: $audioInput) {
                            Text("Built-in Microphone").tag("Built-in Microphone")
                            Text("External Microphone").tag("External Microphone")
                            Text("Aggregate Device").tag("Aggregate Device")
                        }
                        .frame(width: 300)
                    }
                    
                    HStack {
                        Text("Output Device:")
                        Picker("", selection: $audioOutput) {
                            Text("Built-in Output").tag("Built-in Output")
                            Text("External Headphones").tag("External Headphones")
                            Text("Audio Interface").tag("Audio Interface")
                        }
                        .frame(width: 300)
                    }
                    
                    Button(action: {}) {
                        HStack {
                            Image(systemName: "arrow.triangle.2.circlepath")
                            Text("Refresh Devices")
                        }
                    }
                    .buttonStyle(.bordered)
                }
                .padding()
            }
            
            GroupBox("Audio Quality") {
                VStack(alignment: .leading, spacing: 15) {
                    HStack {
                        Text("Sample Rate:")
                        Picker("", selection: $sampleRate) {
                            ForEach(sampleRates, id: \.self) { rate in
                                Text("\(Int(rate)) Hz").tag(rate)
                            }
                        }
                        .frame(width: 150)
                    }
                    
                    HStack {
                        Text("Buffer Size:")
                        Picker("", selection: $bufferSize) {
                            ForEach(bufferSizes, id: \.self) { size in
                                Text("\(size) samples").tag(size)
                            }
                        }
                        .frame(width: 150)
                    }
                    
                    Toggle("Show Advanced Audio Settings", isOn: $showAdvanced)
                }
                .padding()
            }
            
            if showAdvanced {
                GroupBox("Advanced Audio") {
                    VStack(alignment: .leading, spacing: 15) {
                        Toggle("High-precision timing", isOn: .constant(true))
                        Toggle("Multi-core processing", isOn: .constant(true))
                        Toggle("Audio graph logging", isOn: .constant(false))
                    }
                    .padding()
                }
            }
        }
    }
}

struct AccountSettingsView: View {
    @State private var showSubscription: Bool = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Account Settings")
                .font(.headline)
            
            GroupBox("Profile") {
                HStack(spacing: 20) {
                    // Profile image
                    ZStack {
                        Circle()
                            .fill(Color.blue.opacity(0.3))
                            .frame(width: 80, height: 80)
                        
                        Image(systemName: "person.fill")
                            .font(.system(size: 40))
                            .foregroundColor(.white)
                    }
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Music Creator")
                            .font(.headline)
                        
                        Text("music.creator@example.com")
                            .foregroundColor(.secondary)
                        
                        HStack {
                            Text("Pro Plan")
                                .font(.caption)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 2)
                                .background(Color.blue.opacity(0.2))
                                .cornerRadius(4)
                            
                            Text("Renews on Dec 15, 2024")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    Spacer()
                    
                    Button(action: {}) {
                        Text("Edit Profile")
                    }
                    .buttonStyle(.borderedProminent)
                }
                .padding()
            }
            
            GroupBox("Subscription") {
                VStack(alignment: .leading, spacing: 15) {
                    HStack {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("Current Plan: Pro")
                            Text("$19.99/month")
                                .foregroundColor(.secondary)
                        }
                        
                        Spacer()
                        
                        Button(action: { showSubscription.toggle() }) {
                            Text("Manage Subscription")
                        }
                        .buttonStyle(.bordered)
                    }
                    
                    Divider()
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Plan Features:")
                            .font(.subheadline)
                        
                        FeatureRow(text: "Unlimited AI music generation")
                        FeatureRow(text: "Advanced stem separation")
                        FeatureRow(text: "Cloud storage (50GB)")
                        FeatureRow(text: "Priority support")
                        FeatureRow(text: "API access")
                    }
                }
                .padding()
            }
            
            GroupBox("Danger Zone") {
                HStack {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("Delete Account")
                            .font(.headline)
                        Text("Permanently delete your account and all data")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    
                    Spacer()
                    
                    Button(action: {}) {
                        Text("Delete Account")
                    }
                    .buttonStyle(.bordered)
                    .foregroundColor(.red)
                }
                .padding()
            }
        }
        .sheet(isPresented: $showSubscription) {
            SubscriptionView()
        }
    }
}

struct FeatureRow: View {
    let text: String
    
    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "checkmark.circle.fill")
                .foregroundColor(.green)
            
            Text(text)
                .font(.caption)
        }
    }
}

struct SubscriptionView: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Subscription Plans")
                .font(.largeTitle)
                .fontWeight(.bold)
            
            HStack(spacing: 20) {
                PlanCard(
                    name: "Free",
                    price: "$0/month",
                    features: ["5 AI generations/month", "Basic stem separation", "5GB storage"],
                    isSelected: false
                )
                
                PlanCard(
                    name: "Pro",
                    price: "$19.99/month",
                    features: ["Unlimited AI generation", "Advanced stem separation", "50GB storage", "Priority support", "API access"],
                    isSelected: true
                )
                
                PlanCard(
                    name: "Enterprise",
                    price: "Custom",
                    features: ["Everything in Pro", "Custom AI models", "Unlimited storage", "Dedicated support", "SLA guarantee"],
                    isSelected: false
                )
            }
            .padding()
            
            Button(action: { presentationMode.wrappedValue.dismiss() }) {
                Text("Close")
            }
            .buttonStyle(.bordered)
        }
        .padding()
        .frame(width: 900, height: 500)
    }
}

struct PlanCard: View {
    let name: String
    let price: String
    let features: [String]
    let isSelected: Bool
    
    var body: some View {
        VStack(spacing: 15) {
            Text(name)
                .font(.headline)
            
            Text(price)
                .font(.title2)
                .fontWeight(.bold)
            
            Divider()
            
            VStack(alignment: .leading, spacing: 10) {
                ForEach(features, id: \.self) { feature in
                    HStack(spacing: 8) {
                        Image(systemName: "checkmark")
                        Text(feature)
                            .font(.caption)
                    }
                }
            }
            
            Spacer()
            
            Button(action: {}) {
                Text(isSelected ? "Current Plan" : "Upgrade")
            }
            .buttonStyle(.borderedProminent)
            .disabled(isSelected)
        }
        .padding()
        .frame(width: 250, height: 350)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(isSelected ? Color.blue.opacity(0.2) : Color(white: 0.15))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(isSelected ? Color.blue : Color.clear, lineWidth: 2)
        )
    }
}

struct AppearanceSettingsView: View {
    @State private var showWaveform: Bool = true
    @State private var waveformColor: Color = .blue
    @State private var gridOpacity: Double = 0.3
    @State private var trackHeight: Double = 50
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Appearance Settings")
                .font(.headline)
            
            GroupBox("Interface") {
                VStack(alignment: .leading, spacing: 15) {
                    Toggle("Show waveform in tracks", isOn: $showWaveform)
                    
                    HStack {
                        Text("Waveform Color:")
                        ColorPicker("", selection: $waveformColor)
                    }
                    
                    HStack {
                        Text("Grid Opacity:")
                        Slider(value: $gridOpacity, in: 0...1)
                            .frame(width: 200)
                    }
                    
                    HStack {
                        Text("Track Height:")
                        Slider(value: $trackHeight, in: 30...100)
                            .frame(width: 200)
                        Text("\(Int(trackHeight))px")
                    }
                }
                .padding()
            }
            
            GroupBox("DAW View") {
                VStack(alignment: .leading, spacing: 15) {
                    Toggle("Show track numbers", isOn: .constant(true))
                    Toggle("Show clip names", isOn: .constant(true))
                    Toggle("Show grid lines", isOn: .constant(true))
                    Toggle("Snap to grid", isOn: .constant(true))
                }
                .padding()
            }
        }
    }
}

struct NotificationSettingsView: View {
    @Binding var notifications: Bool
    @State private var emailNotifications: Bool = true
    @State private var pushNotifications: Bool = true
    @State private var weeklyReport: Bool = true
    @State private var milestoneAlerts: Bool = true
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Notification Settings")
                .font(.headline)
            
            GroupBox {
                VStack(alignment: .leading, spacing: 15) {
                    Toggle("Enable notifications", isOn: $notifications)
                    
                    if notifications {
                        Divider()
                        
                        Toggle("Email notifications", isOn: $emailNotifications)
                        Toggle("Push notifications", isOn: $pushNotifications)
                        Toggle("Weekly performance report", isOn: $weeklyReport)
                        Toggle("Milestone alerts", isOn: $milestoneAlerts)
                    }
                }
                .padding()
            }
            
            GroupBox("Alert Types") {
                VStack(alignment: .leading, spacing: 15) {
                    Toggle("New follower notifications", isOn: .constant(true))
                    Toggle("Track milestone alerts", isOn: .constant(true))
                    Toggle("Revenue updates", isOn: .constant(true))
                    Toggle("System announcements", isOn: .constant(false))
                }
                .padding()
            }
        }
    }
}

struct AdvancedSettingsView: View {
    @Binding var analyticsOptIn: Bool
    @State private var showDeveloperTools: Bool = false
    @State private var crashReporting: Bool = true
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Advanced Settings")
                .font(.headline)
            
            GroupBox("Privacy") {
                VStack(alignment: .leading, spacing: 15) {
                    Toggle("Help improve the app by sharing usage analytics", isOn: $analyticsOptIn)
                    Toggle("Send crash reports automatically", isOn: $crashReporting)
                    
                    Divider()
                    
                    Button(action: {}) {
                        HStack {
                            Image(systemName: "doc.text")
                            Text("View Privacy Policy")
                        }
                    }
                    .buttonStyle(.bordered)
                    
                    Button(action: {}) {
                        HStack {
                            Image(systemName: "square.and.arrow.up")
                            Text("Export My Data")
                        }
                    }
                    .buttonStyle(.bordered)
                }
                .padding()
            }
            
            GroupBox("Developer") {
                VStack(alignment: .leading, spacing: 15) {
                    Toggle("Show developer tools", isOn: $showDeveloperTools)
                    
                    if showDeveloperTools {
                        Divider()
                        
                        Button(action: {}) {
                            HStack {
                                Image(systemName: "doc.text")
                                Text("View Logs")
                            }
                        }
                        .buttonStyle(.bordered)
                        
                        Button(action: {}) {
                            HStack {
                                Image(systemName: "ant")
                                Text("Debug Mode")
                            }
                        }
                        .buttonStyle(.bordered)
                    }
                }
                .padding()
            }
            
            GroupBox("Danger Zone") {
                HStack {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("Reset All Settings")
                        Text("Restore all settings to their default values")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    
                    Spacer()
                    
                    Button(action: {}) {
                        Text("Reset Settings")
                    }
                    .buttonStyle(.bordered)
                    .foregroundColor(.red)
                }
                .padding()
            }
        }
    }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
            .preferredColorScheme(.dark)
    }
}