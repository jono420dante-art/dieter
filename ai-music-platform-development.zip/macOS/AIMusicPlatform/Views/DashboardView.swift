//
//  DashboardView.swift
//  AIMusicPlatform
//
//  Created by AI Assistant on 2024.
//

import SwiftUI
import Charts

struct DashboardView: View {
    @State private var selectedTimeRange = "Week"
    let timeRanges = ["Day", "Week", "Month", "Year"]
    
    // Sample data
    let weeklyStreams: [(day: String, streams: Int)] = [
        ("Mon", 1250), ("Tue", 1420), ("Wed", 1680), ("Thu", 1890),
        ("Fri", 2150), ("Sat", 2340), ("Sun", 1920)
    ]
    
    let revenueData: [(day: String, revenue: Double)] = [
        ("Mon", 125.50), ("Tue", 142.30), ("Wed", 168.75), ("Thu", 189.20),
        ("Fri", 215.80), ("Sat", 234.10), ("Sun", 192.40)
    ]
    
    let genreDistribution: [(genre: String, percentage: Double)] = [
        ("Synthwave", 35), ("Lo-fi", 25), ("Electronic", 20),
        ("Pop", 12), ("Other", 8)
    ]
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // Header
                HStack {
                    VStack(alignment: .leading) {
                        Text("Dashboard")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                        Text("Welcome back! Here's your music analytics overview.")
                            .foregroundColor(.secondary)
                    }
                    
                    Spacer()
                    
                    Picker("Time Range", selection: $selectedTimeRange) {
                        ForEach(timeRanges, id: \.self) { range in
                            Text(range).tag(range)
                        }
                    }
                    .pickerStyle(.segmented)
                    .frame(width: 200)
                }
                .padding(.bottom, 10)
                
                // Stats Cards
                LazyVGrid(columns: [
                    GridItem(.flexible()),
                    GridItem(.flexible()),
                    GridItem(.flexible()),
                    GridItem(.flexible())
                ], spacing: 20) {
                    StatCard(
                        title: "Total Streams",
                        value: "12,650",
                        change: "+12.5%",
                        icon: "play.circle.fill",
                        color: .blue
                    )
                    
                    StatCard(
                        title: "Revenue",
                        value: "$1,267.50",
                        change: "+8.2%",
                        icon: "dollarsign.circle.fill",
                        color: .green
                    )
                    
                    StatCard(
                        title: "Listeners",
                        value: "3,420",
                        change: "+15.3%",
                        icon: "person.3.fill",
                        color: .purple
                    )
                    
                    StatCard(
                        title: "Tracks",
                        value: "24",
                        change: "+3",
                        icon: "music.note.list",
                        color: .orange
                    )
                }
                
                // Charts
                HStack(spacing: 20) {
                    // Streams Chart
                    VStack(alignment: .leading) {
                        Text("Weekly Streams")
                            .font(.headline)
                            .padding(.bottom, 5)
                        
                        Chart {
                            ForEach(weeklyStreams, id: \.day) { day, streams in
                                BarMark(
                                    x: .value("Day", day),
                                    y: .value("Streams", streams)
                                )
                                .foregroundStyle(.linearGradient(
                                    colors: [Color.blue, Color.blue.opacity(0.6)],
                                    startPoint: .top,
                                    endPoint: .bottom
                                ))
                                .cornerRadius(5)
                            }
                        }
                        .frame(height: 200)
                        .chartYAxis {
                            AxisMarks(position: .leading)
                        }
                    }
                    .padding()
                    .background(Color(white: 0.12))
                    .cornerRadius(12)
                    
                    // Revenue Chart
                    VStack(alignment: .leading) {
                        Text("Revenue Trend")
                            .font(.headline)
                            .padding(.bottom, 5)
                        
                        Chart {
                            ForEach(revenueData, id: \.day) { day, revenue in
                                LineMark(
                                    x: .value("Day", day),
                                    y: .value("Revenue", revenue)
                                )
                                .foregroundStyle(.green)
                                .interpolationMethod(.catmullRom)
                                
                                AreaMark(
                                    x: .value("Day", day),
                                    y: .value("Revenue", revenue)
                                )
                                .foregroundStyle(.linearGradient(
                                    colors: [Color.green.opacity(0.5), Color.green.opacity(0.1)],
                                    startPoint: .top,
                                    endPoint: .bottom
                                ))
                            }
                        }
                        .frame(height: 200)
                        .chartYAxis {
                            AxisMarks(position: .leading)
                        }
                    }
                    .padding()
                    .background(Color(white: 0.12))
                    .cornerRadius(12)
                    
                    // Genre Distribution
                    VStack(alignment: .leading) {
                        Text("Top Genres")
                            .font(.headline)
                            .padding(.bottom, 5)
                        
                        Chart(genreDistribution, id: \.genre) { genre, percentage in
                            SectorMark(
                                angle: .value("Percentage", percentage),
                                innerRadius: .ratio(0.6),
                                angularInset: 2
                            )
                            .foregroundStyle(by: .value("Genre", genre))
                        }
                        .frame(height: 200)
                        .chartLegend(position: .bottom, alignment: .center)
                    }
                    .padding()
                    .background(Color(white: 0.12))
                    .cornerRadius(12)
                }
                
                // Recent Activity
                VStack(alignment: .leading) {
                    Text("Recent Activity")
                        .font(.headline)
                        .padding(.bottom, 10)
                    
                    HStack {
                        Image(systemName: "music.note")
                            .frame(width: 30)
                        
                        VStack(alignment: .leading) {
                            Text("New track uploaded: Neon Dreams")
                                .font(.body)
                            Text("2 hours ago")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        
                        Spacer()
                        
                        Text("Synthwave")
                            .font(.caption)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Color.blue.opacity(0.2))
                            .cornerRadius(4)
                    }
                    .padding()
                    .background(Color(white: 0.12))
                    .cornerRadius(8)
                    
                    HStack {
                        Image(systemName: "chart.line.uptrend.xyaxis")
                            .frame(width: 30)
                        
                        VStack(alignment: .leading) {
                            Text("Stream milestone: 10,000 total streams!")
                                .font(.body)
                            Text("1 day ago")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        
                        Spacer()
                        
                        Text("Achievement")
                            .font(.caption)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Color.orange.opacity(0.2))
                            .cornerRadius(4)
                    }
                    .padding()
                    .background(Color(white: 0.12))
                    .cornerRadius(8)
                    
                    HStack {
                        Image(systemName: "person.badge.plus")
                            .frame(width: 30)
                        
                        VStack(alignment: .leading) {
                            Text("New follower: @electronic_music_fan")
                                .font(.body)
                            Text("3 days ago")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        
                        Spacer()
                        
                        Text("Social")
                            .font(.caption)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Color.purple.opacity(0.2))
                            .cornerRadius(4)
                    }
                    .padding()
                    .background(Color(white: 0.12))
                    .cornerRadius(8)
                }
                .padding(.top, 10)
                
                Spacer()
            }
            .padding()
        }
    }
}

struct StatCard: View {
    let title: String
    let value: String
    let change: String
    let icon: String
    let color: Color
    
    var body: some View {
        HStack(alignment: .top, spacing: 15) {
            Image(systemName: icon)
                .font(.system(size: 28))
                .foregroundColor(color)
                .frame(width: 40, height: 40)
                .background(color.opacity(0.2))
                .cornerRadius(8)
            
            VStack(alignment: .leading, spacing: 5) {
                Text(title)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                Text(value)
                    .font(.title2)
                    .fontWeight(.bold)
                
                Text(change)
                    .font(.caption)
                    .foregroundColor(.green)
            }
            
            Spacer()
        }
        .padding()
        .background(Color(white: 0.12))
        .cornerRadius(12)
    }
}

struct DashboardView_Previews: PreviewProvider {
    static var previews: some View {
        DashboardView()
            .preferredColorScheme(.dark)
    }
}
