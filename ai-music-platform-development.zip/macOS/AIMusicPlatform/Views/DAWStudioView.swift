//
//  DAWStudioView.swift
//  AIMusicPlatform
//
//  Created by AI Assistant on 2024.
//

import SwiftUI
import AVFoundation
import AudioKit
import CoreMIDI

struct DAWStudioView: View {
    @State private var tracks: [DAWTrack] = [
        DAWTrack(id: 1, name: "Synth Lead", type: .synth, volume: 0.8, isMuted: false, isSolo: false, color: .purple),
        DAWTrack(id: 2, name: "Bassline", type: .bass, volume: 0.7, isMuted: false, isSolo: false, color: .blue),
        DAWTrack(id: 3, name: "Drums", type: .drum, volume: 0.6, isMuted: false, isSolo: false, color: .orange),
        DAWTrack(id: 4, name: "Pads", type: .synth, volume: 0.5, isMuted: false, isSolo: false, color: .green),
        DAWTrack(id: 5, name: "Vocals", type: .vocal, volume: 0.9, isMuted: false, isSolo: false, color: .pink)
    ]
    
    @State private var selectedTrackId: Int?
    @State private var currentTime: Double = 0
    @State private var isPlaying = false
    @State private var showMixer = true
    @State private var showEffects = false
    @State private var zoomLevel: Double = 1.0
    @State private var markerPosition: Double = 0
    
    let totalDuration: Double = 180 // 3 minutes in seconds
    
    var body: some View {
        VStack(spacing: 0) {
            // Toolbar
            HStack(spacing: 15) {
                // File operations
                Button(action: {}) {
                    Image(systemName: "doc.badge.plus")
                }
                .help("New Project")
                
                Button(action: {}) {
                    Image(systemName: "folder")
                }
                .help("Open Project")
                
                Button(action: {}) {
                    Image(systemName: "square.and.arrow.down")
                }
                .help("Save Project")
                
                Divider()
                    .frame(height: 20)
                
                // Track operations
                Button(action: addTrack) {
                    Image(systemName: "plus")
                }
                .help("Add Track")
                
                Button(action: deleteSelectedTrack) {
                    Image(systemName: "trash")
                }
                .help("Delete Selected Track")
                .disabled(selectedTrackId == nil)
                
                Divider()
                    .frame(height: 20)
                
                // View options
                Toggle("Mixer", isOn: $showMixer)
                Toggle("Effects", isOn: $showEffects)
                
                Spacer()
                
                // Export
                Button(action: {}) {
                    HStack {
                        Image(systemName: "square.and.arrow.up")
                        Text("Export")
                    }
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
            .background(Color(white: 0.15))
            
            // Transport Controls & Timeline
            VStack(spacing: 0) {
                // Transport
                HStack(spacing: 20) {
                    // Time display
                    Text(formatTime(currentTime))
                        .font(.system(.title, design: .monospaced))
                        .frame(width: 100)
                    
                    // Transport buttons
                    HStack(spacing: 15) {
                        Button(action: { currentTime = 0 }) {
                            Image(systemName: "backward.end.fill")
                                .font(.title2)
                        }
                        .help("Go to Start")
                        
                        Button(action: { currentTime = max(0, currentTime - 5) }) {
                            Image(systemName: "backward.frame.fill")
                                .font(.title2)
                        }
                        .help("Rewind 5 Seconds")
                        
                        Button(action: { isPlaying.toggle() }) {
                            Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                                .font(.title)
                        }
                        .keyboardShortcut(.space, modifiers: [])
                        .help(isPlaying ? "Pause (Space)" : "Play (Space)")
                        
                        Button(action: { currentTime = min(totalDuration, currentTime + 5) }) {
                            Image(systemName: "forward.frame.fill")
                                .font(.title2)
                        }
                        .help("Forward 5 Seconds")
                        
                        Button(action: { currentTime = totalDuration }) {
                            Image(systemName: "forward.end.fill")
                                .font(.title2)
                        }
                        .help("Go to End")
                        
                        Button(action: {}) {
                            Image(systemName: "stop.fill")
                                .font(.title2)
                        }
                        .help("Stop")
                    }
                    
                    Spacer()
                    
                    // Tempo & Zoom
                    HStack(spacing: 15) {
                        VStack(alignment: .trailing, spacing: 2) {
                            Text("Tempo")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            Text("120 BPM")
                                .font(.system(.body, design: .monospaced))
                        }
                        
                        Divider()
                            .frame(height: 30)
                        
                        VStack(alignment: .trailing, spacing: 2) {
                            Text("Zoom")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            Slider(value: $zoomLevel, in: 0.5...2.0)
                                .frame(width: 100)
                        }
                    }
                }
                .padding()
                .background(Color(white: 0.18))
                
                // Timeline Ruler
                GeometryReader { geometry in
                    ZStack(alignment: .leading) {
                        // Background
                        Color(white: 0.12)
                        
                        // Time markers
                        HStack(spacing: 0) {
                            ForEach(0..<Int(totalDuration / 10), id: \.self) { second in
                                let time = Double(second * 10)
                                VStack {
                                    Rectangle()
                                        .fill(Color.gray)
                                        .frame(width: 1, height: 10)
                                    
                                    Text(formatTime(time, includeUnits: false))
                                        .font(.caption2)
                                        .foregroundColor(.secondary)
                                }
                                .frame(width: geometry.size.width / CGFloat(totalDuration / 10))
                            }
                        }
                        
                        // Playhead
                        Rectangle()
                            .fill(Color.red)
                            .frame(width: 2)
                            .offset(x: geometry.size.width * CGFloat(currentTime / totalDuration))
                        
                        // Marker
                        if markerPosition > 0 {
                            Circle()
                                .fill(Color.yellow)
                                .frame(width: 10, height: 10)
                                .offset(x: geometry.size.width * CGFloat(markerPosition / totalDuration) - 5)
                        }
                    }
                }
                .frame(height: 40)
            }
            
            // Main Workspace
            HSplitView {
                // Track List
                VStack(spacing: 0) {
                    // Track headers
                    HStack {
                        Text("Tracks")
                            .font(.headline)
                        
                        Spacer()
                        
                        Button(action: {}) {
                            Image(systemName: "arrow.up.arrow.down")
                        }
                        .help("Sort Tracks")
                    }
                    .padding()
                    .background(Color(white: 0.15))
                    
                    List(selection: $selectedTrackId) {
                        ForEach($tracks) { $track in
                            TrackHeaderView(track: $track, isSelected: selectedTrackId == track.id)
                                .tag(track.id)
                        }
                    }
                    .listStyle(.sidebar)
                }
                .frame(minWidth: 280, idealWidth: 320)
                
                // Timeline/Arrangement View
                VStack(spacing: 0) {
                    // Track lanes
                    ScrollView {
                        VStack(spacing: 0) {
                            ForEach(tracks) { track in
                                TrackLaneView(track: track, currentTime: $currentTime, totalDuration: totalDuration)
                            }
                        }
                    }
                    .background(Color(white: 0.08))
                }
                
                // Mixer Panel (if shown)
                if showMixer {
                    VStack(spacing: 0) {
                        Text("Mixer")
                            .font(.headline)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color(white: 0.15))
                        
                        ScrollView {
                            VStack(spacing: 20) {
                                ForEach($tracks) { $track in
                                    MixerChannelStrip(track: $track)
                                }
                            }
                            .padding()
                        }
                    }
                    .frame(minWidth: 200, idealWidth: 250)
                }
            }
            
            // Bottom Panel - Effects/Inspector
            if showEffects {
                VStack(spacing: 0) {
                    HStack {
                        Text("Effects & Plugins")
                            .font(.headline)
                        
                        Spacer()
                        
                        Button(action: {}) {
                            Image(systemName: "plus")
                        }
                        .help("Add Effect")
                    }
                    .padding()
                    .background(Color(white: 0.15))
                    
                    HStack(spacing: 20) {
                        EffectSlotView(name: "EQ", isEnabled: true)
                        EffectSlotView(name: "Compressor", isEnabled: true)
                        EffectSlotView(name: "Reverb", isEnabled: false)
                        EffectSlotView(name: "Delay", isEnabled: false)
                        EffectSlotView(name: "Distortion", isEnabled: false)
                        
                        Spacer()
                    }
                    .padding()
                }
                .frame(height: 150)
            }
        }
        .navigationTitle("DAW Studio")
        .onAppear {
            // Start a timer to update current time when playing
            Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { _ in
                if isPlaying && currentTime < totalDuration {
                    currentTime += 0.1
                } else if currentTime >= totalDuration {
                    isPlaying = false
                    currentTime = 0
                }
            }
        }
    }
    
    private func formatTime(_ time: Double, includeUnits: Bool = true) -> String {
        let minutes = Int(time) / 60
        let seconds = Int(time) % 60
        let milliseconds = Int((time.truncatingRemainder(dividingBy: 1)) * 100)
        
        if includeUnits {
            return String(format: "%02d:%02d:%02d", minutes, seconds, milliseconds)
        } else {
            return String(format: "%02d:%02d", minutes, seconds)
        }
    }
    
    private func addTrack() {
        let newId = (tracks.map { $0.id }.max() ?? 0) + 1
        let colors: [Color] = [.purple, .blue, .orange, .green, .pink, .yellow, .red, .teal]
        let types: [DAWTrack.TrackType] = [.synth, .audio, .bass, .drum, .vocal]
        
        let newTrack = DAWTrack(
            id: newId,
            name: "Track \(newId)",
            type: types.randomElement() ?? .audio,
            volume: 0.75,
            isMuted: false,
            isSolo: false,
            color: colors.randomElement() ?? .gray
        )
        
        tracks.append(newTrack)
    }
    
    private func deleteSelectedTrack() {
        tracks.removeAll { $0.id == selectedTrackId }
        selectedTrackId = nil
    }
}

struct DAWTrack: Identifiable {
    let id: Int
    var name: String
    var type: TrackType
    var volume: Double
    var isMuted: Bool
    var isSolo: Bool
    var color: Color
    var clips: [Clip] = []
    
    enum TrackType: String, CaseIterable {
        case audio = "Audio"
        case synth = "Synth"
        case drum = "Drums"
        case bass = "Bass"
        case vocal = "Vocals"
        case midi = "MIDI"
    }
}

struct Clip: Identifiable {
    let id: UUID
    var startTime: Double
    var duration: Double
    var color: Color
}

struct TrackHeaderView: View {
    @Binding var track: DAWTrack
    let isSelected: Bool
    
    var body: some View {
        HStack(spacing: 10) {
            // Track color indicator
            RoundedRectangle(cornerRadius: 4)
                .fill(track.color)
                .frame(width: 4, height: 40)
            
            VStack(alignment: .leading, spacing: 5) {
                TextField("Track Name", text: $track.name)
                    .font(.headline)
                    .textFieldStyle(.plain)
                
                HStack(spacing: 5) {
                    Text(track.type.rawValue)
                        .font(.caption)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(track.color.opacity(0.2))
                        .cornerRadius(4)
                    
                    Text("\(Int(track.volume * 100))%")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            Spacer()
            
            // Track controls
            HStack(spacing: 8) {
                Button(action: { track.isMuted.toggle() }) {
                    Image(systemName: track.isMuted ? "speaker.slash.fill" : "speaker.fill")
                        .foregroundColor(track.isMuted ? .red : .secondary)
                }
                .buttonStyle(.borderless)
                .help(track.isMuted ? "Unmute" : "Mute")
                
                Button(action: { track.isSolo.toggle() }) {
                    Text("S")
                        .font(.caption)
                        .fontWeight(.bold)
                        .frame(width: 20, height: 20)
                        .background(track.isSolo ? Color.yellow : Color.gray.opacity(0.3))
                        .cornerRadius(4)
                        .foregroundColor(track.isSolo ? .black : .secondary)
                }
                .buttonStyle(.borderless)
                .help(track.isSolo ? "Disable Solo" : "Solo")
            }
        }
        .padding(.vertical, 8)
        .padding(.horizontal, 10)
        .background(
            RoundedRectangle(cornerRadius: 8)
                .fill(isSelected ? Color.blue.opacity(0.2) : Color.clear)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(isSelected ? Color.blue : Color.clear, lineWidth: 2)
        )
    }
}

struct TrackLaneView: View {
    let track: DAWTrack
    @Binding var currentTime: Double
    let totalDuration: Double
    
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                // Background
                track.color.opacity(0.05)
                
                // Grid lines
                HStack(spacing: 0) {
                    ForEach(0..<Int(totalDuration / 10), id: \.self) { _ in
                        Rectangle()
                            .fill(Color.gray.opacity(0.2))
                            .frame(width: 1)
                            .frame(maxHeight: .infinity)
                        
                        Spacer()
                    }
                }
                
                // Clips
                HStack(spacing: 0) {
                    // Sample clips
                    if track.id == 1 {
                        ClipView(color: track.color, startPercentage: 0, durationPercentage: 0.3)
                        ClipView(color: track.color, startPercentage: 0.4, durationPercentage: 0.3)
                    } else if track.id == 2 {
                        ClipView(color: track.color, startPercentage: 0.1, durationPercentage: 0.25)
                        ClipView(color: track.color, startPercentage: 0.45, durationPercentage: 0.25)
                        ClipView(color: track.color, startPercentage: 0.8, durationPercentage: 0.2)
                    } else if track.id == 3 {
                        ClipView(color: track.color, startPercentage: 0, durationPercentage: 1.0)
                    } else if track.id == 4 {
                        ClipView(color: track.color, startPercentage: 0.2, durationPercentage: 0.4)
                        ClipView(color: track.color, startPercentage: 0.7, durationPercentage: 0.3)
                    } else if track.id == 5 {
                        ClipView(color: track.color, startPercentage: 0.3, durationPercentage: 0.35)
                        ClipView(color: track.color, startPercentage: 0.75, durationPercentage: 0.25)
                    }
                }
                
                // Playhead line
                Rectangle()
                    .fill(Color.red)
                    .frame(width: 2)
                    .offset(x: geometry.size.width * CGFloat(currentTime / totalDuration))
            }
        }
        .frame(height: 50)
        .border(Color.gray.opacity(0.3), width: 1)
    }
}

struct ClipView: View {
    let color: Color
    let startPercentage: Double
    let durationPercentage: Double
    
    var body: some View {
        GeometryReader { geometry in
            RoundedRectangle(cornerRadius: 4)
                .fill(
                    LinearGradient(
                        gradient: Gradient(colors: [color.opacity(0.8), color.opacity(0.5)]),
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 4)
                        .stroke(color, lineWidth: 1)
                )
                .frame(
                    width: geometry.size.width * durationPercentage,
                    height: 40
                )
                .offset(x: geometry.size.width * startPercentage, y: 5)
        }
    }
}

struct MixerChannelStrip: View {
    @Binding var track: DAWTrack
    
    var body: some View {
        VStack(spacing: 10) {
            // Track name
            Text(track.name)
                .font(.caption)
                .fontWeight(.bold)
                .lineLimit(1)
            
            // Track type icon
            Image(systemName: track.type == .synth ? "waveform" : 
                         track.type == .drum ? "drum" :
                         track.type == .bass ? "hifispeaker" :
                         track.type == .vocal ? "mic" : "music.note")
                .foregroundColor(track.color)
            
            // Mute/Solo buttons
            HStack(spacing: 10) {
                Button(action: { track.isMuted.toggle() }) {
                    Image(systemName: track.isMuted ? "speaker.slash" : "speaker")
                        .font(.caption)
                }
                .buttonStyle(.borderless)
                .foregroundColor(track.isMuted ? .red : .secondary)
                
                Button(action: { track.isSolo.toggle() }) {
                    Text("S")
                        .font(.caption)
                        .fontWeight(.bold)
                }
                .buttonStyle(.borderless)
                .foregroundColor(track.isSolo ? .yellow : .secondary)
            }
            
            // Volume fader
            VStack(spacing: 5) {
                Text("Vol")
                    .font(.caption2)
                    .foregroundColor(.secondary)
                
                Slider(value: $track.volume, in: 0...1)
                    .frame(height: 80)
                    .rotationEffect(.degrees(-90))
                    .frame(width: 80, height: 30)
                
                Text("\(Int(track.volume * 100))%")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            // Level meter
            VStack(spacing: 2) {
                ForEach(0..<8) { i in
                    RoundedRectangle(cornerRadius: 2)
                        .fill(i < 5 ? Color.green : i < 7 ? Color.yellow : Color.red)
                        .frame(width: 20, height: 6)
                        .opacity(i < 4 ? 1.0 : 0.3)
                }
            }
        }
        .padding()
        .background(Color(white: 0.12))
        .cornerRadius(8)
    }
}

struct EffectSlotView: View {
    let name: String
    @State var isEnabled: Bool
    
    var body: some View {
        VStack(spacing: 8) {
            Toggle(isOn: $isEnabled) {
                Text(name)
                    .font(.caption)
                    .fontWeight(.medium)
            }
            .toggleStyle(.switch)
            
            RoundedRectangle(cornerRadius: 8)
                .fill(isEnabled ? Color.blue.opacity(0.3) : Color.gray.opacity(0.2))
                .frame(width: 100, height: 60)
                .overlay(
                    Image(systemName: "slider.horizontal.3")
                        .foregroundColor(isEnabled ? .blue : .gray)
                )
        }
    }
}

struct DAWStudioView_Previews: PreviewProvider {
    static var previews: some View {
        DAWStudioView()
            .preferredColorScheme(.dark)
    }
}
