//
//  AIMusicPlatformApp.swift
//  AIMusicPlatform
//
//  Created by AI Assistant on 2024.
//

import SwiftUI
import AVFoundation
import AudioKit

@main
struct AIMusicPlatformApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    @StateObject private var audioEngine = AudioEngine()
    @State private var isPlaying = false
    @State private var bpm: Double = 120
    @State private var currentTime: Double = 0
    @State private var selectedSidebarItem: SidebarItem = .dashboard
    
    enum SidebarItem: String, CaseIterable, Identifiable {
        case dashboard = "Dashboard"
        case generator = "AI Generator"
        case daw = "DAW Studio"
        case stem = "Stem Separator"
        case library = "Track Library"
        case analytics = "Analytics"
        case settings = "Settings"
        
        var id: String { rawValue }
        
        var icon: String {
            switch self {
            case .dashboard: return "house.fill"
            case .generator: return "wand.and.stars"
            case .daw: return "waveform"
            case .stem: return "scissors"
            case .library: return "music.note.list"
            case .analytics: return "chart.bar.fill"
            case .settings: return "gearshape.fill"
            }
        }
        
        var color: Color {
            switch self {
            case .dashboard: return .blue
            case .generator: return .purple
            case .daw: return .pink
            case .stem: return .green
            case .library: return .orange
            case .analytics: return .red
            case .settings: return .gray
            }
        }
    }
    
    var body: some Scene {
        WindowGroup {
            NavigationView {
                // Sidebar
                List(selection: $selectedSidebarItem) {
                    Section("Main") {
                        ForEach(SidebarItem.allCases.filter { $0 != .settings }) { item in
                            Label(item.rawValue, systemImage: item.icon)
                                .tag(item)
                                .listRowBackground(selectedSidebarItem == item ? item.color.opacity(0.3) : Color.clear)
                        }
                    }
                    
                    Section("Library") {
                        Label("Recent Projects", systemImage: "clock")
                        Label("Favorites", systemImage: "heart")
                        Label("Samples", systemImage: "folder")
                    }
                    
                    Section {
                        Label("Settings", systemImage: "gearshape.fill")
                            .tag(SidebarItem.settings)
                    }
                }
                .listStyle(.sidebar)
                .frame(minWidth: 220)
                .toolbar {
                    ToolbarItem(placement: .navigation) {
                        Button(action: toggleSidebar) {
                            Image(systemName: "sidebar.left")
                        }
                    }
                }
                
                // Main Content
                Group {
                    switch selectedSidebarItem {
                    case .dashboard:
                        DashboardView()
                    case .generator:
                        MusicGeneratorView()
                    case .daw:
                        DAWStudioView()
                    case .stem:
                        StemSeparatorView()
                    case .library:
                        TrackLibraryView()
                    case .analytics:
                        AnalyticsView()
                    case .settings:
                        SettingsView()
                    }
                }
                .frame(minWidth: 800, minHeight: 600)
            }
            .navigationTitle("AI Music Production Platform")
            .toolbar {
                ToolbarItem(placement: .automatic) {
                    HStack(spacing: 12) {
                        Button(action: { currentTime = 0 }) {
                            Image(systemName: "backward.end.fill")
                                .font(.title2)
                        }
                        .help("Go to Start")
                        
                        Button(action: { isPlaying.toggle() }) {
                            Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                                .font(.title)
                        }
                        .keyboardShortcut(.space, modifiers: [])
                        .help(isPlaying ? "Pause (Space)" : "Play (Space)")
                        
                        Button(action: { audioEngine.stop() }) {
                            Image(systemName: "stop.fill")
                                .font(.title2)
                        }
                        .help("Stop")
                        
                        Button(action: {}) {
                            Image(systemName: "forward.end.fill")
                                .font(.title2)
                        }
                        .help("Go to End")
                        
                        Divider()
                            .frame(height: 20)
                        
                        VStack(alignment: .trailing, spacing: 2) {
                            Text("BPM: \(Int(bpm))")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            Slider(value: $bpm, in: 60...180)
                                .frame(width: 120)
                        }
                        
                        Divider()
                            .frame(height: 20)
                        
                        VStack(alignment: .trailing, spacing: 2) {
                            Text("Master Volume")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            Slider(value: $audioEngine.masterVolume, in: 0...1)
                                .frame(width: 100)
                        }
                    }
                    .padding(.horizontal, 8)
                }
            }
        }
        .windowStyle(.hiddenTitleBar)
        .windowToolbarStyle(.unified(showsTitle: true))
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("New Project", action: newProject)
                    .keyboardShortcut("n", modifiers: .command)
                
                Button("Open Project", action: openProject)
                    .keyboardShortcut("o", modifiers: .command)
            }
            
            CommandMenu("Track") {
                Button("Add Track", action: {})
                    .keyboardShortcut("t", modifiers: .command)
                
                Button("Delete Selected Track", action: {})
                    .keyboardShortcut(.delete, modifiers: .command)
            }
        }
    }
    
    private func toggleSidebar() {
        NSApp.keyWindow?.firstResponder?.tryToPerform(#selector(NSSplitViewController.toggleSidebar(_:)), with: nil)
    }
    
    private func newProject() {
        // Implementation for new project
        print("New project created")
    }
    
    private func openProject() {
        // Implementation for open project
        print("Open project panel")
    }
}

class AppDelegate: NSObject, NSApplicationDelegate {
    func applicationDidFinishLaunching(_ notification: Notification) {
        // Set dark mode by default
        NSApp.appearance = NSAppearance(named: .darkAqua)
        
        // Request audio permissions
        AVCaptureDevice.requestAccess(for: .audio) { granted in
            if granted {
                print("Audio access granted")
            } else {
                print("Audio access denied")
            }
        }
        
        // Initialize audio session
        do {
            try AVAudioSession.sharedInstance().setCategory(.playAndRecord)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            print("Failed to set up audio session: \(error)")
        }
    }
    
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return true
    }
}

// Audio Engine Class
class AudioEngine: ObservableObject {
    @Published var masterVolume: Float = 0.8
    @Published var isPlaying = false
    
    private let engine = AVAudioEngine()
    private let player = AVAudioPlayerNode()
    private let mixer = AVAudioMixerNode()
    
    init() {
        setupEngine()
    }
    
    private func setupEngine() {
        engine.attach(player)
        engine.attach(mixer)
        
        let format = AVAudioFormat(standardFormatWithSampleRate: 44100, channels: 2)
        engine.connect(player, to: mixer, format: format)
        engine.connect(mixer, to: engine.outputNode, format: format)
        
        mixer.outputVolume = masterVolume
        
        do {
            try engine.start()
        } catch {
            print("Error starting audio engine: \(error.localizedDescription)")
        }
    }
    
    func play() {
        player.play()
        isPlaying = true
    }
    
    func pause() {
        player.pause()
        isPlaying = false
    }
    
    func stop() {
        player.stop()
        isPlaying = false
    }
}
